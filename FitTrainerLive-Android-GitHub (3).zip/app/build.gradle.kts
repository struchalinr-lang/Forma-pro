plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fittrainer.live"
    compileSdk = 34

    val runNum = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 10
    defaultConfig {
        applicationId = "com.fittrainer.live"
        minSdk = 26
        targetSdk = 34
        versionCode = 100 + runNum
        versionName = "2.0.$runNum"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("fittrainer-release-key.jks")
            storePassword = "fittrainer123"
            keyAlias = "fittrainer"
            keyPassword = "fittrainer123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.webkit:webkit:1.10.0")
}
