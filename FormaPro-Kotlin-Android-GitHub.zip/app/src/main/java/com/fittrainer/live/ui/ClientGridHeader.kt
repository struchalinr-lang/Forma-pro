package com.fittrainer.live.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittrainer.live.model.*
import com.fittrainer.live.theme.LiquidGlassCard
import com.fittrainer.live.theme.LocalFormaPalette
import com.fittrainer.live.theme.NewYearGarlandBar

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ClientGridHeader(
    clients: List<ClientProgram>,
    activeClientId: String,
    settings: AppSettings,
    timersByClient: Map<String, ClientTimerState>,
    onSelectClient: (String) -> Unit,
    onLongPressClient: (ClientProgram) -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalFormaPalette.current
    if (clients.isEmpty()) return

    val pages = clients.chunked(6)
    val pagerState = rememberPagerState(pageCount = { pages.size.coerceAtLeast(1) })

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
    ) {
        // Title + Santa Hat + Smooth Animated Pagination Dots
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp, bottom = 2.dp)
        ) {
            Row(
                modifier = Modifier.align(Alignment.Center),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Клиенты",
                    color = p.textPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                if (p.id == AppThemeId.NEWYEAR) {
                    Text(text = " 🎅", fontSize = 13.sp)
                }
            }

            if (pages.size > 1) {
                Row(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(pages.size) { idx ->
                        val isCurrent = pagerState.currentPage == idx
                        val dotWidth by animateDpAsState(
                            targetValue = if (isCurrent) 14.dp else 6.dp,
                            animationSpec = tween(220),
                            label = "dotWidth"
                        )
                        val dotColor by animateColorAsState(
                            targetValue = if (isCurrent) p.accent else p.textMuted.copy(alpha = 0.42f),
                            animationSpec = tween(220),
                            label = "dotColor"
                        )
                        Box(
                            modifier = Modifier
                                .width(dotWidth)
                                .height(6.dp)
                                .clip(CircleShape)
                                .background(dotColor)
                        )
                    }
                }
            }
        }

        NewYearGarlandBar()

        // Native 120Hz 3x2 Swipeable Client Grid
        HorizontalPager(
            state = pagerState,
            pageSpacing = 10.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 6.dp)
        ) { pageIdx ->
            val pageClients = pages[pageIdx]
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                for (row in 0 until 2) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        for (col in 0 until 3) {
                            val itemIdx = row * 3 + col
                            val client = pageClients.getOrNull(itemIdx)
                            if (client != null) {
                                ClientMiniCard(
                                    client = client,
                                    isActive = client.id == activeClientId,
                                    hasWorkoutToday = settings.softSorting && TonnageMath.clientHasWorkoutToday(client),
                                    showPin = settings.pinMode && client.pinned,
                                    hasTimer = timersByClient[client.id]?.running == true,
                                    garlandIdx = (pageIdx * 6 + itemIdx) % 4,
                                    onClick = { onSelectClient(client.id) },
                                    onLongClick = { onLongPressClient(client) },
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Spacer(modifier = Modifier.weight(1f).height(62.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ClientMiniCard(
    client: ClientProgram,
    isActive: Boolean,
    hasWorkoutToday: Boolean,
    showPin: Boolean,
    hasTimer: Boolean,
    garlandIdx: Int,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalFormaPalette.current
    val (done, total) = client.completedCount()
    val pct = if (total > 0) (done.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
    val garlandColors = listOf(Color(0xFFFDE047), Color(0xFFFB7185), Color(0xFF38BDF8), Color(0xFF34D399))

    LiquidGlassCard(
        modifier = modifier
            .height(62.dp)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        cornerRadius = 16.dp,
        strong = isActive,
        activeBorder = isActive,
        showSnowCap = true
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = (if (showPin) "📌 " else "") + client.name,
                    color = if (isActive) p.accent else p.textPrimary,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (hasWorkoutToday) {
                        if (p.id == AppThemeId.NEWYEAR) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(Color.White, garlandColors[garlandIdx])
                                        )
                                    )
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(p.todayDot)
                            )
                        }
                    }
                    if (hasTimer) {
                        Text(text = "⏱", fontSize = 10.sp, color = p.accent)
                    }
                }
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Нед ${client.activeWeek} • Д${client.activeDay}",
                        color = p.textSecondary,
                        fontSize = 9.5.sp,
                        maxLines = 1
                    )
                    Text(
                        text = "$done/$total",
                        color = p.textSecondary,
                        fontSize = 9.5.sp,
                        maxLines = 1
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(CircleShape)
                        .background(p.textMuted.copy(alpha = 0.25f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(pct)
                            .clip(CircleShape)
                            .background(p.accent)
                    )
                }
            }
        }
    }
}
