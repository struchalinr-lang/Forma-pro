package com.fittrainer.live

import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.fittrainer.live.model.*
import com.fittrainer.live.theme.*
import com.fittrainer.live.ui.*
import kotlinx.coroutines.launch
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request highest native display refresh rate (120Hz / 90Hz)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) this.display
                else @Suppress("DEPRECATION") windowManager.defaultDisplay
                val bestMode = display?.supportedModes?.maxByOrNull { it.refreshRate }
                if (bestMode != null) {
                    val params = window.attributes
                    params.preferredDisplayModeId = bestMode.modeId
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        params.preferredRefreshRate = bestMode.refreshRate
                    }
                    window.attributes = params
                }
            }
        } catch (_: Exception) {}

        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            val vm: FormaViewModel = viewModel()
            val themeId = vm.state.theme
            val palette = remember(themeId) { paletteFor(themeId) }

            SideEffect {
                val colorInt = AndroidColor.parseColor(themeId.statusBarHex)
                window.statusBarColor = colorInt
                window.navigationBarColor = colorInt
                WindowInsetsControllerCompat(window, window.decorView).let {
                    it.isAppearanceLightStatusBars = !themeId.isDark
                    it.isAppearanceLightNavigationBars = !themeId.isDark
                }
            }

            CompositionLocalProvider(LocalFormaPalette provides palette) {
                FormaProRootScreen(vm = vm)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FormaProRootScreen(vm: FormaViewModel) {
    val p = LocalFormaPalette.current
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val pagerState = rememberPagerState(initialPage = vm.state.activeTab.coerceIn(0, 4), pageCount = { 5 })
    val workoutsListState = rememberLazyListState()
    val analyticsListState = rememberLazyListState()

    // SINGLE UNIFIED CLIENT GRID OFFSET (Native 120Hz RenderThread NestedScroll — ZERO jelly, ZERO duplicate dots!)
    var clientGridHeightPx by remember { mutableFloatStateOf(0f) }
    val gridOffsetY = remember { Animatable(0f) }
    var viewportWidthPx by remember { mutableFloatStateOf(1080f) }

    var showBuilderDialog by remember { mutableStateOf(false) }
    var editingClient by remember { mutableStateOf<ClientProgram?>(null) }
    var pendingCsvClient by remember { mutableStateOf<ClientProgram?>(null) }

    // File Launchers (JSON Backup Export/Import + CSV Export)
    val exportJsonLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(FormaJsonCodec.toJson(vm.state).toByteArray(Charsets.UTF_8))
                }
                vm.showToast("Бэкап .json сохранён")
            } catch (e: Exception) {
                vm.showToast("Ошибка сохранения: ${e.message}")
            }
        }
    }

    val importJsonLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (!text.isNullOrBlank()) vm.importBackupJson(text)
            } catch (e: Exception) {
                vm.showToast("Ошибка чтения файла")
            }
        }
    }

    val exportCsvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        val cl = pendingCsvClient
        if (uri != null && cl != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(vm.repo.exportClientCsv(cl).toByteArray(Charsets.UTF_8))
                }
                vm.showToast("Таблица ${cl.name}.csv сохранена")
            } catch (e: Exception) {
                vm.showToast("Ошибка экспорта CSV")
            }
        }
        pendingCsvClient = null
    }

    // 2-Mode Physics between Workouts (2) and Analytics (3):
    // Mode 1: Cards still visible (abs(gridOffsetY) < gridHeight) -> keep cards steady at exact same Y!
    // Mode 2: Cards already scrolled off-screen -> smoothly bring cards back to 0 on destination tab!
    LaunchedEffect(pagerState.currentPage) {
        val page = pagerState.currentPage
        if (page == 2 || page == 3) {
            if (clientGridHeightPx > 0f && abs(gridOffsetY.value) >= clientGridHeightPx - 8f) {
                if (page == 2) workoutsListState.scrollToItem(0)
                if (page == 3) analyticsListState.scrollToItem(0)
                gridOffsetY.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 420f))
            }
        }
    }

    val nestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (clientGridHeightPx <= 0f) return Offset.Zero
                val page = pagerState.currentPage
                if (page != 2 && page != 3) return Offset.Zero
                val dy = available.y
                val cur = gridOffsetY.value
                val next = (cur + dy).coerceIn(-clientGridHeightPx, 0f)
                if (next != cur) {
                    scope.launch { gridOffsetY.snapTo(next) }
                }
                return Offset.Zero
            }
        }
    }

    val pagerFloat = pagerState.currentPage + pagerState.currentPageOffsetFraction
    val topSpacerDp = with(density) {
        if (clientGridHeightPx > 0f) clientGridHeightPx.toDp() else 172.dp
    }

    // Ambient full-screen Liquid Glass background
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
            .systemBarsPadding()
            .onSizeChanged { viewportWidthPx = it.width.toFloat().coerceAtLeast(1f) }
    ) {
        // 5-Tab Native Telegram HorizontalPager
        HorizontalPager(
            state = pagerState,
            beyondBoundsPageCount = 1,
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(nestedScrollConnection)
        ) { pageIdx ->
            when (pageIdx) {
                0 -> TablesTabContent(
                    vm = vm,
                    onExportCsv = { cl ->
                        pendingCsvClient = cl
                        exportCsvLauncher.launch("${cl.name}.csv")
                    },
                    onOpenWorkouts = { scope.launch { pagerState.animateScrollToPage(2) } }
                )
                1 -> ClientsTabContent(
                    vm = vm,
                    onOpenWorkouts = { scope.launch { pagerState.animateScrollToPage(2) } },
                    onEditClient = { cl ->
                        editingClient = cl
                        showBuilderDialog = true
                    }
                )
                2 -> WorkoutsTabContent(
                    vm = vm,
                    listState = workoutsListState,
                    topSpacerHeight = topSpacerDp,
                    onEditClient = { cl ->
                        editingClient = cl
                        showBuilderDialog = true
                    }
                )
                3 -> AnalyticsTabContent(
                    vm = vm,
                    listState = analyticsListState,
                    topSpacerHeight = topSpacerDp
                )
                else -> SettingsTabContent(
                    vm = vm,
                    onExportJsonBackup = { exportJsonLauncher.launch("FormaPro_Backup.json") },
                    onImportJsonBackup = { importJsonLauncher.launch(arrayOf("application/json", "*/*")) }
                )
            }
        }

        // SINGLE UNIFIED CLIENT GRID HEADER (Glides 1:1 with Workouts 1<->2 and Analytics 3<->4, locked 0px on 2<->3!)
        val showSharedGrid = pagerFloat > 1.01f && pagerFloat < 3.99f && vm.state.clients.isNotEmpty()
        if (showSharedGrid) {
            val gridTx = when {
                pagerFloat < 2f -> (2f - pagerFloat) * viewportWidthPx
                pagerFloat > 3f -> (3f - pagerFloat) * viewportWidthPx
                else -> 0f
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .onSizeChanged { clientGridHeightPx = it.height.toFloat() }
                    .graphicsLayer {
                        translationX = gridTx
                        translationY = gridOffsetY.value
                    }
            ) {
                ClientGridHeader(
                    clients = vm.getOrderedClients(),
                    activeClientId = vm.state.activeClientId,
                    settings = vm.state.settings,
                    timersByClient = vm.state.timersByClient,
                    onSelectClient = { vm.selectClient(it) },
                    onLongPressClient = { cl ->
                        if (vm.state.settings.pinMode) {
                            vm.togglePinClient(cl.id)
                            vm.showToast(if (!cl.pinned) "📌 ${cl.name} закреплён" else "Карточка откреплена")
                        } else {
                            editingClient = cl
                            showBuilderDialog = true
                        }
                    }
                )
            }
        }

        // Telegram-Style Fixed Circular "+" FAB on Clients Tab (index 1)
        val fabVisible = abs(1f - pagerFloat) < 0.38f
        val fabScale by animateFloatAsState(
            targetValue = if (fabVisible) 1f else 0f,
            animationSpec = spring(dampingRatio = 0.62f, stiffness = 420f),
            label = "fabScale"
        )
        if (fabScale > 0.02f) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 22.dp, bottom = 94.dp)
                    .size(56.dp)
                    .scale(fabScale)
                    .alpha(fabScale.coerceIn(0f, 1f))
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(p.accent, p.accentStrong)))
                    .clickable(enabled = fabVisible) {
                        editingClient = null
                        showBuilderDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Добавить программу", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }

        // Stacked Timer Alerts Banner at Top
        AnimatedVisibility(
            visible = vm.timerAlerts.isNotEmpty(),
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            vm.timerAlerts.firstOrNull()?.let { alert ->
                LiquidGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            vm.selectClient(alert.clientId)
                            vm.dismissAlert(alert.id)
                            scope.launch { pagerState.animateScrollToPage(2) }
                        },
                    cornerRadius = 20.dp,
                    strong = true,
                    activeBorder = true,
                    showSnowCap = false
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("⏱ Отдых завершён — ${alert.clientName}", color = p.accent, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold)
                            Text(alert.exerciseName, color = p.textPrimary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { vm.dismissAlert(alert.id) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Rounded.Close, contentDescription = null, tint = p.textSecondary, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        // Floating Toast Message
        AnimatedVisibility(
            visible = vm.toastMessage != null,
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 92.dp, start = 20.dp, end = 20.dp)
        ) {
            vm.toastMessage?.let { msg ->
                LiquidGlassCard(cornerRadius = 16.dp, strong = true, showSnowCap = false) {
                    Text(
                        text = "✓  $msg",
                        color = p.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                    )
                }
            }
        }

        // Floating Bottom Navigation Capsule
        BottomNavCapsule(
            pagerPosition = pagerFloat,
            onSelectTab = { targetIdx ->
                scope.launch {
                    if (targetIdx == 2) {
                        workoutsListState.animateScrollToItem(0)
                        gridOffsetY.animateTo(0f)
                    } else if (targetIdx == 3) {
                        analyticsListState.animateScrollToItem(0)
                        gridOffsetY.animateTo(0f)
                    }
                    pagerState.animateScrollToPage(targetIdx)
                }
            },
            modifier = Modifier.align(Alignment.BottomCenter)
        )

        // Native 120Hz New Year Snowfall Overlay (non-interactive)
        NewYearSnowOverlay()
    }

    if (showBuilderDialog) {
        ProgramBuilderDialog(
            initialClient = editingClient,
            onSave = { saved ->
                vm.upsertClient(saved)
                showBuilderDialog = false
                editingClient = null
                scope.launch { pagerState.animateScrollToPage(2) }
            },
            onDismiss = {
                showBuilderDialog = false
                editingClient = null
            }
        )
    }
}
