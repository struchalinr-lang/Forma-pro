package com.fittrainer.live.data

import android.content.Context
import com.fittrainer.live.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class FormaRepository(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "fittrainer_prefs"
        private const val KEY_STATE = "workout_state_backup"
        const val SUPABASE_URL = "https://bhuovqmvxlxzcvghtica.supabase.co"
        const val SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJodW92cW12eGx4emN2Z2h0aWNhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ5MTE1MjYsImV4cCI6MjExMDQ4NzUyNn0.Bp-1100si7VgzrQ8WPldL1WCgwJxonXV0TYD0X6uRA4"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadLocalState(): AppState {
        val raw = prefs.getString(KEY_STATE, null)
        if (!raw.isNullOrBlank()) {
            FormaJsonCodec.fromJson(raw)?.let { return it }
        }
        val demos = ProExerciseLibrary.createDemoClients()
        return AppState(
            theme = AppThemeId.NEWYEAR,
            activeTab = 2,
            activeClientId = demos.first().id,
            clients = demos
        )
    }

    fun saveLocalState(state: AppState) {
        val json = FormaJsonCodec.toJson(state)
        prefs.edit().putString(KEY_STATE, json).apply()
    }

    data class AuthResult(
        val success: Boolean,
        val accessToken: String = "",
        val refreshToken: String = "",
        val userId: String = "",
        val email: String = "",
        val error: String = ""
    )

    suspend fun supabaseSignIn(email: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        try {
            val url = URL("$SUPABASE_URL/auth/v1/token?grant_type=password")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 10000
                readTimeout = 12000
                setRequestProperty("apikey", SUPABASE_ANON_KEY)
                setRequestProperty("Content-Type", "application/json")
            }
            val body = JSONObject().put("email", email.trim()).put("password", password).toString()
            OutputStreamWriter(conn.outputStream).use { it.write(body) }

            val code = conn.responseCode
            val respText = readStream(if (code in 200..299) conn.inputStream else conn.errorStream)
            val json = JSONObject(respText)
            if (code in 200..299) {
                val userObj = json.optJSONObject("user")
                AuthResult(
                    success = true,
                    accessToken = json.optString("access_token", ""),
                    refreshToken = json.optString("refresh_token", ""),
                    userId = userObj?.optString("id", "") ?: "",
                    email = userObj?.optString("email", email.trim()) ?: email.trim()
                )
            } else {
                val msg = json.optString("error_description", json.optString("msg", "Ошибка входа ($code)"))
                AuthResult(false, error = msg)
            }
        } catch (e: Exception) {
            AuthResult(false, error = e.message ?: "Нет подключения к сети")
        }
    }

    suspend fun supabaseSignUp(email: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        try {
            val url = URL("$SUPABASE_URL/auth/v1/signup")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 10000
                readTimeout = 12000
                setRequestProperty("apikey", SUPABASE_ANON_KEY)
                setRequestProperty("Content-Type", "application/json")
            }
            val body = JSONObject().put("email", email.trim()).put("password", password).toString()
            OutputStreamWriter(conn.outputStream).use { it.write(body) }

            val code = conn.responseCode
            val respText = readStream(if (code in 200..299) conn.inputStream else conn.errorStream)
            val json = JSONObject(respText)
            if (code in 200..299) {
                val token = json.optString("access_token", "")
                if (token.isNotBlank()) {
                    val userObj = json.optJSONObject("user")
                    AuthResult(
                        success = true,
                        accessToken = token,
                        refreshToken = json.optString("refresh_token", ""),
                        userId = userObj?.optString("id", "") ?: "",
                        email = userObj?.optString("email", email.trim()) ?: email.trim()
                    )
                } else {
                    supabaseSignIn(email, password)
                }
            } else {
                val msg = json.optString("msg", json.optString("error_description", ""))
                if (msg.contains("already registered", ignoreCase = true)) {
                    supabaseSignIn(email, password)
                } else {
                    AuthResult(false, error = msg.ifBlank { "Ошибка регистрации ($code)" })
                }
            }
        } catch (e: Exception) {
            AuthResult(false, error = e.message ?: "Нет подключения к сети")
        }
    }

    suspend fun pushToSupabase(state: AppState): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val token = state.settings.sbAccessToken
        val uid = state.settings.sbUserId
        if (token.isBlank() || uid.isBlank()) return@withContext false to "Сначала войдите в облачный аккаунт"

        try {
            val url = URL("$SUPABASE_URL/rest/v1/trainer_states?on_conflict=user_id")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 10000
                readTimeout = 15000
                setRequestProperty("apikey", SUPABASE_ANON_KEY)
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Prefer", "resolution=merge-duplicates,return=minimal")
            }
            val payload = JSONObject()
                .put("user_id", uid)
                .put("state_json", JSONObject(FormaJsonCodec.toJson(state)))
                .put("updated_at", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()))
            OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }

            val code = conn.responseCode
            if (code in 200..299) {
                val nowStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                true to nowStr
            } else {
                false to "Ошибка облака ($code)"
            }
        } catch (e: Exception) {
            false to (e.message ?: "Ошибка сети")
        }
    }

    suspend fun pullFromSupabase(settings: AppSettings): Pair<AppState?, String> = withContext(Dispatchers.IO) {
        val token = settings.sbAccessToken
        val uid = settings.sbUserId
        if (token.isBlank() || uid.isBlank()) return@withContext null to "Сначала войдите в облачный аккаунт"

        try {
            val url = URL("$SUPABASE_URL/rest/v1/trainer_states?user_id=eq.$uid&select=state_json")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 15000
                setRequestProperty("apikey", SUPABASE_ANON_KEY)
                setRequestProperty("Authorization", "Bearer $token")
            }
            val code = conn.responseCode
            val resp = readStream(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code in 200..299) {
                val arr = JSONArray(resp)
                if (arr.length() == 0) return@withContext null to "В облаке пока нет сохранённых данных"
                val stateJson = arr.getJSONObject(0).optJSONObject("state_json")
                    ?: return@withContext null to "Пустой снимок в облаке"
                val parsed = FormaJsonCodec.fromJson(stateJson.toString())
                    ?: return@withContext null to "Не удалось разобрать данные облака"
                val nowStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                parsed.copy(settings = parsed.settings.copy(
                    sbAccessToken = settings.sbAccessToken,
                    sbRefreshToken = settings.sbRefreshToken,
                    sbUserId = settings.sbUserId,
                    sbUserEmail = settings.sbUserEmail,
                    sbLastSyncAt = nowStr
                )) to "Загружено из облака ($nowStr)"
            } else {
                null to "Ошибка загрузки ($code)"
            }
        } catch (e: Exception) {
            null to (e.message ?: "Ошибка сети")
        }
    }

    fun parsePastedCells(clientName: String, rawText: String): ClientProgram? {
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null
        val daysMap = mutableMapOf<Int, MutableList<ExerciseItem>>()
        val dayNames = mutableMapOf<Int, String>()
        var currentDayIdx = 1
        dayNames[1] = "День 1"
        val intReg = Regex("\\d+")
        val setsReg = Regex("(\\d+)\\s*[xх×]", RegexOption.IGNORE_CASE)
        val rpeReg = Regex("RPE\\s*(\\d+)", RegexOption.IGNORE_CASE)

        for (line in lines) {
            val cols = line.split("\t", ";").map { it.trim() }
            if (cols.isEmpty()) continue
            val firstLower = cols[0].lowercase()
            if (firstLower.contains("упражн") && firstLower.contains("день")) continue

            val maybeDay = cols[0]
            if (maybeDay.isNotEmpty() && listOf("понед", "вторн", "сред", "четв", "пятн", "субб", "воскр", "день").any { firstLower.contains(it) }) {
                val existingIdx = dayNames.entries.firstOrNull { it.value.equals(maybeDay, ignoreCase = true) }?.key
                if (existingIdx != null) {
                    currentDayIdx = existingIdx
                } else {
                    currentDayIdx = if (daysMap[1].isNullOrEmpty() && dayNames[1] == "День 1") 1 else dayNames.size + 1
                    dayNames[currentDayIdx] = maybeDay.replaceFirstChar { it.uppercase() }
                }
            }

            val exName = cols.getOrNull(1)?.takeIf { it.isNotBlank() } ?: cols[0]
            if (exName.equals(dayNames[currentDayIdx], ignoreCase = true) && cols.size == 1) continue
            val reps = cols.getOrNull(2)?.takeIf { it.isNotBlank() } ?: "10-12"
            val restStr = cols.getOrNull(3) ?: "2"
            val restMin = intReg.find(restStr)?.value?.toIntOrNull() ?: 2
            val restSec = if (restMin > 15) restMin else restMin * 60
            val sets = setsReg.find(cols.getOrNull(4) ?: "")?.groupValues?.get(1)?.toIntOrNull() ?: 3
            val rpe = rpeReg.find(cols.getOrNull(4) ?: "")?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(6, 10) ?: 8
            val weight = cols.getOrNull(5) ?: ""

            val weeks = (1..6).associateWith { wk ->
                ExerciseWeekData(sets = sets, reps = reps, rpe = rpe, weight = if (wk == 1) weight else "")
            }
            daysMap.getOrPut(currentDayIdx) { mutableListOf() }.add(
                ExerciseItem(id = UUID.randomUUID().toString(), name = exName, restSec = restSec, weeks = weeks)
            )
        }

        if (daysMap.isEmpty()) return null
        val workoutDays = daysMap.mapValues { (idx, list) ->
            WorkoutDay(idx, dayNames[idx] ?: "День $idx", list)
        }.toSortedMap()

        return ClientProgram(
            id = UUID.randomUUID().toString(),
            name = clientName.ifBlank { "Новый клиент" },
            totalWeeks = 6,
            activeWeek = 1,
            activeDay = workoutDays.keys.first(),
            days = workoutDays
        )
    }

    fun exportClientCsv(client: ClientProgram): String {
        val sb = StringBuilder()
        sb.appendLine("День недели;Упражнение;Подходы;Повторы;Отдых (сек);RPE;Вес (Нед ${client.activeWeek})")
        for ((_, day) in client.days.toSortedMap()) {
            for (ex in day.exercises) {
                val wd = ex.weekData(client.activeWeek)
                sb.appendLine("${day.name};${ex.name};${wd.sets};${wd.reps};${ex.restSec};${wd.rpe};${wd.weight}")
            }
        }
        return sb.toString()
    }

    private fun readStream(stream: InputStream?): String {
        if (stream == null) return "{}"
        return BufferedReader(InputStreamReader(stream)).use { it.readText() }
    }
}
