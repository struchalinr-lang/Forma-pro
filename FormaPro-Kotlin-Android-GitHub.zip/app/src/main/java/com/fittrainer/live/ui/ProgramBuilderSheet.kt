package com.fittrainer.live.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.fittrainer.live.model.*
import com.fittrainer.live.theme.LiquidGlassCard
import com.fittrainer.live.theme.LocalFormaPalette
import java.util.UUID

@Composable
fun ProgramBuilderDialog(
    initialClient: ClientProgram?,
    onSave: (ClientProgram) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalFormaPalette.current
    var clientName by remember { mutableStateOf(initialClient?.name ?: "") }
    var totalWeeks by remember { mutableIntStateOf(initialClient?.totalWeeks ?: 6) }
    var daysMap by remember {
        mutableStateOf(
            initialClient?.days?.toMap() ?: mapOf(
                1 to WorkoutDay(1, "Понедельник", emptyList()),
                2 to WorkoutDay(2, "Среда", emptyList()),
                3 to WorkoutDay(3, "Пятница", emptyList())
            )
        )
    }
    var activeDayIdx by remember { mutableIntStateOf(daysMap.keys.minOrNull() ?: 1) }
    var selectedMuscleIdx by remember { mutableIntStateOf(0) }
    var customExerciseName by remember { mutableStateOf("") }

    val currentDay = daysMap[activeDayIdx] ?: WorkoutDay(activeDayIdx, "День $activeDayIdx", emptyList())

    fun addExerciseToDay(name: String) {
        if (name.isBlank()) return
        val weeks = (1..totalWeeks).associateWith { ExerciseWeekData(sets = 3, reps = "10-12", rpe = 8) }
        val newItem = ExerciseItem(id = UUID.randomUUID().toString(), name = name.trim(), restSec = 120, weeks = weeks)
        daysMap = daysMap + (activeDayIdx to currentDay.copy(exercises = currentDay.exercises + newItem))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        LiquidGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .padding(horizontal = 10.dp),
            cornerRadius = 26.dp,
            strong = true,
            showSnowCap = false
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (initialClient != null) "Редактор программы" else "Конструктор программы",
                            color = p.textPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text("Сборка сплита и упражнений в 1 касание", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Закрыть", tint = p.textPrimary)
                    }
                }

                // Fully scrollable body (LazyColumn fixes every scroll issue natively!)
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Client Name + Weeks
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(modifier = Modifier.weight(1.3f)) {
                                Text("ИМЯ КЛИЕНТА", color = p.textSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(38.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(p.wellBg)
                                        .padding(horizontal = 10.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    BasicTextField(
                                        value = clientName,
                                        onValueChange = { clientName = it },
                                        singleLine = true,
                                        textStyle = TextStyle(color = p.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold),
                                        cursorBrush = SolidColor(p.accent),
                                        modifier = Modifier.fillMaxWidth(),
                                        decorationBox = { inner ->
                                            if (clientName.isEmpty()) Text("Например: Дмитрий", color = p.textMuted, fontSize = 12.sp)
                                            inner()
                                        }
                                    )
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("НЕДЕЛИ", color = p.textSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(38.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(p.wellBg)
                                        .padding(3.dp),
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    listOf(4, 6, 8).forEach { w ->
                                        val act = totalWeeks == w
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .fillMaxHeight()
                                                .clip(RoundedCornerShape(9.dp))
                                                .background(if (act) p.accentPillBg else Color.Transparent)
                                                .clickable { totalWeeks = w },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("$w", color = if (act) p.accent else p.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Split Presets + Day Tabs
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(p.cardBg)
                                .border(1.dp, p.cardBorder, RoundedCornerShape(18.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("СПЛИТ:", color = p.textSecondary, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                                listOf(
                                    "3 дня" to listOf("Понедельник", "Среда", "Пятница"),
                                    "4 дня" to listOf("Понедельник", "Вторник", "Четверг", "Пятница"),
                                    "5 дней" to listOf("День 1", "День 2", "День 3", "День 4", "День 5")
                                ).forEach { (label, names) ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(p.wellBg)
                                            .clickable {
                                                daysMap = names.mapIndexed { idx, n ->
                                                    val dIdx = idx + 1
                                                    dIdx to WorkoutDay(dIdx, n, daysMap[dIdx]?.exercises ?: emptyList())
                                                }.toMap()
                                                activeDayIdx = 1
                                            }
                                            .padding(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Text(label, color = p.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                daysMap.values.sortedBy { it.dayIndex }.forEach { d ->
                                    val act = d.dayIndex == activeDayIdx
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (act) p.accentPillBg else p.wellBg)
                                            .border(if (act) 1.dp else 0.dp, if (act) p.accentBorder else Color.Transparent, RoundedCornerShape(12.dp))
                                            .clickable { activeDayIdx = d.dayIndex }
                                            .padding(horizontal = 12.dp, vertical = 7.dp)
                                    ) {
                                        Text(d.name, color = if (act) p.accent else p.textPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                            }
                        }
                    }

                    // Pro Exercise Library (1-Tap to Add)
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(p.cardBg)
                                .border(1.dp, p.cardBorder, RoundedCornerShape(18.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("⚡ БАЗА УПРАЖНЕНИЙ (ТАП — ДОБАВИТЬ)", color = p.textSecondary, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                ProExerciseLibrary.muscleGroups.forEachIndexed { idx, (groupName, _) ->
                                    val act = idx == selectedMuscleIdx
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (act) p.accentPillBg else p.wellBg)
                                            .clickable { selectedMuscleIdx = idx }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(groupName, color = if (act) p.accent else p.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                            }

                            val chips = ProExerciseLibrary.muscleGroups[selectedMuscleIdx].second
                            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                chips.forEach { exName ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(p.wellBg)
                                            .clickable { addExerciseToDay(exName) }
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(exName, color = p.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                        Text("＋", color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                            }

                            // Custom Exercise row
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(p.wellBg)
                                        .padding(horizontal = 10.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    BasicTextField(
                                        value = customExerciseName,
                                        onValueChange = { customExerciseName = it },
                                        singleLine = true,
                                        textStyle = TextStyle(color = p.textPrimary, fontSize = 12.sp),
                                        cursorBrush = SolidColor(p.accent),
                                        modifier = Modifier.fillMaxWidth(),
                                        decorationBox = { inner ->
                                            if (customExerciseName.isEmpty()) Text("Своё упражнение...", color = p.textMuted, fontSize = 12.sp)
                                            inner()
                                        }
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .height(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(p.accentPillBg)
                                        .border(1.dp, p.accentBorder, RoundedCornerShape(10.dp))
                                        .clickable {
                                            if (customExerciseName.isNotBlank()) {
                                                addExerciseToDay(customExerciseName)
                                                customExerciseName = ""
                                            }
                                        }
                                        .padding(horizontal = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("Добавить", color = p.accent, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
                                }
                            }
                        }
                    }

                    // Exercises added to current day
                    item {
                        Text(
                            text = "Упражнения (${currentDay.name}): ${currentDay.exercises.size}",
                            color = p.textPrimary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    itemsIndexed(currentDay.exercises, key = { _, ex -> ex.id }) { idx, ex ->
                        val wd = ex.weekData(1)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(p.wellBg)
                                .border(0.8.dp, p.cardBorder, RoundedCornerShape(14.dp))
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                Text("${idx + 1}. ${ex.name}", color = p.textPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${wd.sets} × ${wd.reps} • Отдых ${ex.restSec / 60}м • RPE ${wd.rpe}", color = p.textSecondary, fontSize = 10.5.sp)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(p.cardBg)
                                        .clickable {
                                            val nextSets = if (wd.sets >= 5) 2 else wd.sets + 1
                                            val updWeeks = ex.weeks.mapValues { (_, v) -> v.copy(sets = nextSets) }
                                            val nextList = currentDay.exercises.map { if (it.id == ex.id) it.copy(weeks = updWeeks) else it }
                                            daysMap = daysMap + (activeDayIdx to currentDay.copy(exercises = nextList))
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("${wd.sets}", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                }
                                IconButton(
                                    onClick = {
                                        val nextList = currentDay.exercises.filter { it.id != ex.id }
                                        daysMap = daysMap + (activeDayIdx to currentDay.copy(exercises = nextList))
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Удалить", tint = Color(0xFFFB7185), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                // Fixed Save Button at bottom of modal
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                        .height(46.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.verticalGradient(listOf(p.accent, p.accentStrong)))
                        .clickable {
                            val result = ClientProgram(
                                id = initialClient?.id ?: UUID.randomUUID().toString(),
                                name = clientName.ifBlank { "Новый клиент" },
                                totalWeeks = totalWeeks,
                                activeWeek = initialClient?.activeWeek ?: 1,
                                activeDay = daysMap.keys.minOrNull() ?: 1,
                                pinned = initialClient?.pinned ?: false,
                                days = daysMap.toSortedMap(),
                                measurements = initialClient?.measurements ?: emptyMap()
                            )
                            onSave(result)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (initialClient != null) "✓ Сохранить изменения" else "✓ Создать программу клиента",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}
