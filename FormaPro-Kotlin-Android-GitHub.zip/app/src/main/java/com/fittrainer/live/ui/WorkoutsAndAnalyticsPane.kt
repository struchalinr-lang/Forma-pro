package com.fittrainer.live.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittrainer.live.model.*
import com.fittrainer.live.theme.LiquidGlassCard
import com.fittrainer.live.theme.LocalFormaPalette
import kotlin.math.ceil

@Composable
fun WorkoutsTabContent(
    vm: FormaViewModel,
    listState: LazyListState,
    topSpacerHeight: Dp,
    onEditClient: (ClientProgram) -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalFormaPalette.current
    val client = vm.activeClient()
    var showCompletedSpoiler by remember { mutableStateOf(false) }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 14.dp,
            end = 14.dp,
            top = topSpacerHeight,
            bottom = 104.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (client == null) {
            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Нет активных клиентов", color = p.textPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Создайте программу во вкладке «Клиенты» или импортируйте таблицу.", color = p.textSecondary, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
            return@LazyColumn
        }

        // 1. Week & Day Selector Card
        item(key = "navigator") {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Weeks Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(p.wellBg)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        for (w in 1..client.totalWeeks.coerceAtMost(8)) {
                            val active = w == client.activeWeek
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (active) p.accentPillBg else Color.Transparent)
                                    .border(
                                        width = if (active) 1.dp else 0.dp,
                                        color = if (active) p.accentBorder else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { vm.setActiveWeek(w) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Нед $w",
                                    color = if (active) p.accent else p.textSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (active) FontWeight.ExtraBold else FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    // Days Row
                    val sortedDays = client.days.values.sortedBy { it.dayIndex }
                    if (sortedDays.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(p.wellBg)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            sortedDays.forEach { d ->
                                val active = d.dayIndex == client.activeDay
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (active) p.accentPillBg else Color.Transparent)
                                        .border(
                                            width = if (active) 1.dp else 0.dp,
                                            color = if (active) p.accentBorder else Color.Transparent,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { vm.setActiveDay(d.dayIndex) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = d.name,
                                        color = if (active) p.accent else p.textSecondary,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (active) FontWeight.ExtraBold else FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        val dayObj = client.currentDay()
        val allEx = dayObj?.exercises ?: emptyList()
        val completedList = allEx.filter { it.weekData(client.activeWeek).status == "completed" }
        val pendingList = allEx.filter { it.weekData(client.activeWeek).status != "completed" }
        val activeEx = pendingList.firstOrNull()
        val nextEx = pendingList.getOrNull(1)
        val queueRest = if (pendingList.size > 2) pendingList.drop(2) else emptyList()

        // 2. Collapsible Completed Spoiler Bar
        item(key = "completed_spoiler") {
            LiquidGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showCompletedSpoiler = !showCompletedSpoiler },
                cornerRadius = 18.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("✓ ", color = p.accent, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                            Text(
                                text = "Выполнено: ${completedList.size} из ${allEx.size} упр.",
                                color = p.textPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp
                            )
                        }
                        Icon(
                            imageVector = if (showCompletedSpoiler) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                            contentDescription = null,
                            tint = p.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    AnimatedVisibility(visible = showCompletedSpoiler && completedList.isNotEmpty()) {
                        Column(
                            modifier = Modifier.padding(top = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            completedList.forEach { ex ->
                                val wd = ex.weekData(client.activeWeek)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(p.wellBg)
                                        .clickable { vm.uncompleteExercise(ex.id) }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "✓ ${ex.name}",
                                        color = p.textPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "${wd.weight.ifBlank { "—" }} • ${wd.sets}×${wd.reps}",
                                        color = p.textSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Active Exercise Focus Card
        if (activeEx != null) {
            item(key = "active_ex_${activeEx.id}") {
                ActiveExerciseCard(
                    client = client,
                    ex = activeEx,
                    vm = vm,
                    onEditProgram = { onEditClient(client) }
                )
            }
        } else if (allEx.isNotEmpty()) {
            item(key = "all_done") {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🎉 Тренировка завершена!", color = p.accent, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Все упражнения дня выполнены. Можно перейти к следующему дню или неделе.", color = p.textSecondary, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        // 4. Next Exercise Preview
        if (nextEx != null) {
            val nwd = nextEx.weekData(client.activeWeek)
            item(key = "next_ex_${nextEx.id}") {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 18.dp) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Text("ДАЛЕЕ: ", color = p.accent, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                            Text(
                                text = nextEx.name,
                                color = p.textPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = "${nwd.sets}×${nwd.reps} • RPE ${nwd.rpe}",
                            color = p.textSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // 5. Remaining Queue
        if (queueRest.isNotEmpty()) {
            item(key = "queue_card") {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        queueRest.forEachIndexed { idx, ex ->
                            val qwd = ex.weekData(client.activeWeek)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 7.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "○  ${ex.name}",
                                    color = p.textPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${qwd.sets}×${qwd.reps} • RPE ${qwd.rpe}",
                                    color = p.textSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            if (idx < queueRest.lastIndex) {
                                HorizontalDivider(color = p.cardBorder, thickness = 0.7.dp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveExerciseCard(
    client: ClientProgram,
    ex: ExerciseItem,
    vm: FormaViewModel,
    onEditProgram: () -> Unit
) {
    val p = LocalFormaPalette.current
    val wd = ex.weekData(client.activeWeek)
    val prevWeight = if (client.activeWeek > 1) ex.weekData(client.activeWeek - 1).weight else ""
    val timer = vm.state.timersByClient[client.id]
    val nowMs = vm.nowMs
    val timerRunning = timer != null && timer.running && timer.endTimeMs > nowMs
    val remSec = if (timerRunning) ceil((timer!!.endTimeMs - nowMs) / 1000.0).toInt().coerceAtLeast(0) else ex.restSec
    val timerFrac = if (timerRunning && timer != null && timer.totalDurationSec > 0) {
        (1f - (timer.endTimeMs - nowMs).toFloat() / (timer.totalDurationSec * 1000f)).coerceIn(0f, 1f)
    } else 0f

    fun adjustWeight(cur: String, delta: Double): String {
        val trimmed = cur.trim()
        val pair = Regex("(\\d+(?:\\.\\d+)?)\\s*\\+\\s*(\\d+(?:\\.\\d+)?)").find(trimmed)
        if (pair != null) {
            val v = (pair.groupValues[1].toDoubleOrNull() ?: 0.0) + (if (delta > 0) 1.0 else -1.0)
            val nv = v.coerceAtLeast(0.0)
            val s = if (nv % 1.0 == 0.0) nv.toInt().toString() else nv.toString()
            return "$s+$s"
        }
        val num = Regex("\\d+(?:\\.\\d+)?").find(trimmed.replace(',', '.'))?.value?.toDoubleOrNull() ?: 0.0
        val next = (num + delta).coerceAtLeast(0.0)
        return if (next % 1.0 == 0.0) next.toInt().toString() else String.format("%.1f", next)
    }

    LiquidGlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 24.dp, strong = true) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = ex.name,
                    color = p.textPrimary,
                    fontSize = 15.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(p.wellBg)
                            .border(1.dp, p.cardBorder, CircleShape)
                            .clickable { onEditProgram() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Edit, contentDescription = "Редактировать", tint = p.accent, modifier = Modifier.size(16.dp))
                    }
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(p.wellBg)
                            .border(1.dp, p.cardBorder, CircleShape)
                            .clickable { vm.skipExercise(ex.id) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.FastForward, contentDescription = "Пропустить", tint = p.accent, modifier = Modifier.size(17.dp))
                    }
                }
            }

            // Sets x Reps + Weight row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Sets x Reps box
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(p.wellBg)
                        .border(1.dp, p.cardBorder, RoundedCornerShape(18.dp))
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("ПОДХОДЫ × ПОВТОРЫ", color = p.textSecondary, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SmallRoundBtn("−") {
                            vm.updateActiveExercise(ex.id) { it.copy(sets = (it.sets - 1).coerceAtLeast(1)) }
                        }
                        Text("${wd.sets} × ${wd.reps}", color = p.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.ExtraBold)
                        SmallRoundBtn("+") {
                            vm.updateActiveExercise(ex.id) { it.copy(sets = (it.sets + 1).coerceAtMost(12)) }
                        }
                    }
                }

                // Weight box with Previous Week badge + BW button
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(p.wellBg)
                        .border(1.dp, p.cardBorder, RoundedCornerShape(18.dp))
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("ВЕС", color = p.textSecondary, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                        if (prevWeight.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(p.accentPillBg)
                                    .border(0.8.dp, p.accentBorder, RoundedCornerShape(8.dp))
                                    .clickable { vm.updateActiveExercise(ex.id) { it.copy(weight = prevWeight) } }
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text("НЕД ${client.activeWeek - 1}: $prevWeight", color = p.accent, fontSize = 8.5.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SmallRoundBtn("−") {
                            vm.updateActiveExercise(ex.id) { it.copy(weight = adjustWeight(it.weight, -2.5)) }
                        }
                        BasicTextField(
                            value = wd.weight,
                            onValueChange = { v -> vm.updateActiveExercise(ex.id) { it.copy(weight = v) } },
                            singleLine = true,
                            textStyle = TextStyle(
                                color = p.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = TextAlign.Center
                            ),
                            cursorBrush = SolidColor(p.accent),
                            modifier = Modifier.weight(1f),
                            decorationBox = { inner ->
                                Box(contentAlignment = Alignment.Center) {
                                    if (wd.weight.isEmpty()) Text("—", color = p.textMuted, fontWeight = FontWeight.Bold)
                                    inner()
                                }
                            }
                        )
                        Box(
                            modifier = Modifier
                                .height(28.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(p.cardBg)
                                .border(1.dp, p.cardBorder, RoundedCornerShape(14.dp))
                                .clickable {
                                    vm.updateActiveExercise(ex.id) {
                                        it.copy(weight = if (it.weight == "BW") adjustWeight("0", 2.5) else if (it.weight.isBlank()) "BW" else adjustWeight(it.weight, 2.5))
                                    }
                                }
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(if (wd.weight.isBlank()) "BW" else "+", color = p.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }

            // RPE 6..10 Sliding Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(p.wellBg)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (rpeVal in 6..10) {
                    val active = wd.rpe == rpeVal
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (active) p.accentPillBg else Color.Transparent)
                            .border(
                                width = if (active) 1.dp else 0.dp,
                                color = if (active) p.accentBorder else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { vm.updateActiveExercise(ex.id) { it.copy(rpe = rpeVal) } },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$rpeVal",
                            color = if (active) p.accent else p.textSecondary,
                            fontSize = 13.sp,
                            fontWeight = if (active) FontWeight.ExtraBold else FontWeight.SemiBold
                        )
                    }
                }
            }

            // Interactive 60fps Rest Timer Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(p.wellBg)
                    .border(1.dp, p.accentBorder.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
                    .clickable {
                        vm.startOrToggleTimer(client.id, client.name, ex.name, ex.restSec)
                    }
            ) {
                if (timerRunning) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(timerFrac)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(p.accent.copy(alpha = 0.28f), p.accentStrong.copy(alpha = 0.48f))
                                )
                            )
                    )
                }
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val mm = (remSec / 60).toString().padStart(2, '0')
                    val ss = (remSec % 60).toString().padStart(2, '0')
                    Text("⏱ ", color = p.accent, fontSize = 14.sp)
                    Text(
                        text = if (timerRunning) "Отдых: $mm:$ss (стоп)" else "Отдых: $mm:$ss",
                        color = p.textPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            // Complete Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(p.accent, p.accentStrong)))
                    .clickable { vm.completeExercise(ex.id) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "✓  Выполнено",
                    color = Color.White,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

@Composable
private fun SmallRoundBtn(label: String, onClick: () -> Unit) {
    val p = LocalFormaPalette.current
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(p.cardBg)
            .border(1.dp, p.cardBorder, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun AnalyticsTabContent(
    vm: FormaViewModel,
    listState: LazyListState,
    topSpacerHeight: Dp,
    modifier: Modifier = Modifier
) {
    val p = LocalFormaPalette.current
    val client = vm.activeClient()

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 14.dp,
            end = 14.dp,
            top = topSpacerHeight,
            bottom = 104.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (client == null) return@LazyColumn

        val sortedDays = client.days.values.sortedBy { it.dayIndex }
        val activeDayObj = client.currentDay()
        val curTonnage = TonnageMath.computeDayTonnageKg(activeDayObj, client.activeWeek)
        val prevWeekTonnage = if (client.activeWeek > 1) TonnageMath.computeDayTonnageKg(activeDayObj, client.activeWeek - 1) else 0
        val diffPrevWeek = curTonnage - prevWeekTonnage

        // 1. Daily Tonnage Summary & Grid
        item(key = "analytics_tonnage") {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${client.name} — Аналитика",
                            color = p.textPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(p.accentPillBg)
                                .border(1.dp, p.accentBorder, RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("Нед ${client.activeWeek} • ${activeDayObj?.name ?: ""}", color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    // 2 KPI tiles
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(p.wellBg)
                                .padding(10.dp)
                        ) {
                            Text("ТОННАЖ ДНЯ", color = p.textSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(3.dp))
                            Text("$curTonnage кг", color = p.accent, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(p.wellBg)
                                .padding(10.dp)
                        ) {
                            Text(if (client.activeWeek > 1) "К НЕД ${client.activeWeek - 1}" else "К НЕД 1", color = p.textSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(3.dp))
                            val sign = if (diffPrevWeek > 0) "+" else ""
                            Text(
                                text = if (client.activeWeek > 1) "$sign$diffPrevWeek кг" else "Старт",
                                color = p.textPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    // Training days cards
                    Text("Сетка тоннажа по тренировочным дням (кг)", color = p.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    sortedDays.chunked(2).forEach { pair ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { d ->
                                val t = TonnageMath.computeDayTonnageKg(d, client.activeWeek)
                                val sets = TonnageMath.computeDaySetsCount(d, client.activeWeek)
                                val (done, total) = client.completedCount(client.activeWeek, d.dayIndex)
                                val isSel = d.dayIndex == client.activeDay
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(if (isSel) p.accentPillBg else p.wellBg)
                                        .border(
                                            width = if (isSel) 1.dp else 0.7.dp,
                                            color = if (isSel) p.accentBorder else p.cardBorder,
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                        .clickable { vm.setActiveDay(d.dayIndex) }
                                        .padding(10.dp)
                                ) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(d.name, color = p.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("$done/$total", color = p.textSecondary, fontSize = 10.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("$t кг", color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                                    Text("Подходов: $sets", color = p.textSecondary, fontSize = 10.sp)
                                }
                            }
                            if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                        }
                    }

                    // Weekly Matrix
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(p.wellBg)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text("День", color = p.textSecondary, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(86.dp))
                            for (w in 1..client.totalWeeks.coerceAtMost(6)) {
                                Text(
                                    text = "Н$w",
                                    color = if (w == client.activeWeek) p.accent else p.textSecondary,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        sortedDays.forEach { d ->
                            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(d.name, color = p.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(86.dp))
                                for (w in 1..client.totalWeeks.coerceAtMost(6)) {
                                    val t = TonnageMath.computeDayTonnageKg(d, w)
                                    Text(
                                        text = if (t > 0) "$t" else "—",
                                        color = if (w == client.activeWeek) p.accent else p.textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = if (w == client.activeWeek) FontWeight.ExtraBold else FontWeight.Medium,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Body Measurements Table
        item(key = "analytics_measurements") {
            val fields = listOf(
                "weight" to "Вес тела (кг)",
                "waist" to "Талия (см)",
                "chest" to "Грудь (см)",
                "hips" to "Ягодицы (см)",
                "biceps" to "Бицепс (см)",
                "thigh" to "Бедро (см)"
            )
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("📏 Антропометрия и замеры тела", color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Вносите замеры по неделям для отслеживания динамики", color = p.textSecondary, fontSize = 11.sp)

                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Параметр", color = p.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(108.dp))
                                for (w in 1..client.totalWeeks.coerceAtMost(6)) {
                                    Text(
                                        text = "Нед $w",
                                        color = if (w == client.activeWeek) p.accent else p.textSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(64.dp)
                                    )
                                }
                            }
                            fields.forEach { (key, label) ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(label, color = p.textPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(108.dp))
                                    for (w in 1..client.totalWeeks.coerceAtMost(6)) {
                                        val valStr = client.measurements[w]?.get(key) ?: ""
                                        Box(
                                            modifier = Modifier
                                                .width(64.dp)
                                                .padding(horizontal = 3.dp)
                                                .height(30.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(p.wellBg)
                                                .border(0.8.dp, p.cardBorder, RoundedCornerShape(10.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            BasicTextField(
                                                value = valStr,
                                                onValueChange = { vm.updateMeasurement(w, key, it) },
                                                singleLine = true,
                                                textStyle = TextStyle(color = p.textPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
                                                cursorBrush = SolidColor(p.accent),
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                                decorationBox = { inner ->
                                                    Box(contentAlignment = Alignment.Center) {
                                                        if (valStr.isEmpty()) Text("—", color = p.textMuted, fontSize = 11.sp)
                                                        inner()
                                                    }
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
