package com.fittrainer.live.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittrainer.live.model.AppThemeId
import com.fittrainer.live.theme.LocalFormaPalette
import kotlin.math.roundToInt

private data class NavTabItem(val index: Int, val label: String, val icon: ImageVector)

private val NAV_ITEMS = listOf(
    NavTabItem(0, "Таблицы", Icons.Rounded.TableChart),
    NavTabItem(1, "Клиенты", Icons.Rounded.Group),
    NavTabItem(2, "Тренировки", Icons.Rounded.FitnessCenter),
    NavTabItem(3, "Аналитика", Icons.Rounded.BarChart),
    NavTabItem(4, "Настройки", Icons.Rounded.Settings)
)

@Composable
fun BottomNavCapsule(
    pagerPosition: Float, // 0f..4f continuous from HorizontalPager!
    onSelectTab: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalFormaPalette.current
    val activeIdx = pagerPosition.roundToInt().coerceIn(0, 4)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 14.dp)
    ) {
        // Galloping Santa Sleigh along the top border of the bottom bar in New Year theme
        if (p.id == AppThemeId.NEWYEAR) {
            val infinite = rememberInfiniteTransition(label = "santa")
            val progress by infinite.animateFloat(
                initialValue = -0.15f,
                targetValue = 1.15f,
                animationSpec = infiniteRepeatable(
                    animation = tween(9200, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "santaX"
            )
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .padding(horizontal = 12.dp)
            ) {
                val xDp = maxWidth * progress
                Text(
                    text = "🛷🎅🦌🦌",
                    fontSize = 13.sp,
                    modifier = Modifier.offset(x = xDp, y = 2.dp)
                )
            }
        }

        // Translucent Floating Capsule aligned pixel-for-pixel with cards working width
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(62.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(p.navBg)
                .border(1.dp, p.cardBorder, RoundedCornerShape(32.dp))
                .padding(horizontal = 6.dp, vertical = 5.dp)
        ) {
            val slotWidth = maxWidth / 5f
            val clampedPos = pagerPosition.coerceIn(0f, 4f)

            // 1:1 GPU-driven sliding active pill
            Box(
                modifier = Modifier
                    .offset(x = slotWidth * clampedPos)
                    .width(slotWidth)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(26.dp))
                    .background(p.accentPillBg)
                    .border(1.dp, p.accentBorder.copy(alpha = 0.45f), RoundedCornerShape(26.dp))
            )

            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NAV_ITEMS.forEach { item ->
                    val isSelected = activeIdx == item.index
                    val iconScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.12f else 1f,
                        animationSpec = spring(dampingRatio = 0.65f, stiffness = 420f),
                        label = "tabScale"
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onSelectTab(item.index) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = if (isSelected) p.accent else p.textMuted,
                            modifier = Modifier
                                .size(23.dp)
                                .scale(iconScale)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.label,
                            color = if (isSelected) p.accent else p.textMuted,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Clip
                        )
                    }
                }
            }
        }
    }
}
