package com.fittrainer.live.ui

import android.app.Application
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fittrainer.live.data.FormaRepository
import com.fittrainer.live.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class FormaViewModel(application: Application) : AndroidViewModel(application) {
    val repo = FormaRepository(application)

    var state by mutableStateOf(repo.loadLocalState())
        private set

    var timerAlerts by mutableStateOf<List<TimerAlert>>(emptyList())
        private set

    var toastMessage by mutableStateOf<String?>(null)
        private set

    var nowMs by mutableLongStateOf(System.currentTimeMillis())
        private set

    private var toneGenerator: ToneGenerator? = null

    init {
        viewModelScope.launch {
            while (true) {
                if (state.timersByClient.isNotEmpty()) {
                    val cur = System.currentTimeMillis()
                    nowMs = cur
                    checkExpiredTimers(cur)
                    delay(50L)
                } else {
                    delay(350L)
                }
            }
        }
    }

    fun showToast(msg: String) {
        toastMessage = msg
        viewModelScope.launch {
            delay(2600L)
            if (toastMessage == msg) toastMessage = null
        }
    }

    private fun updateAndSave(transform: (AppState) -> AppState) {
        state = transform(state)
        repo.saveLocalState(state)
    }

    fun getOrderedClients(): List<ClientProgram> {
        val list = state.clients
        if (!state.settings.softSorting && !state.settings.pinMode) return list
        return list.sortedWith(
            compareByDescending<ClientProgram> { if (state.settings.pinMode) it.pinned else false }
                .thenByDescending { if (state.settings.softSorting) TonnageMath.clientHasWorkoutToday(it) else false }
        )
    }

    fun activeClient(): ClientProgram? =
        state.clients.firstOrNull { it.id == state.activeClientId } ?: state.clients.firstOrNull()

    fun selectClient(clientId: String) {
        updateAndSave { s ->
            var nextClients = s.clients
            if (s.settings.softSorting) {
                val ordered = getOrderedClients()
                val idx = ordered.indexOfFirst { it.id == clientId }
                if (idx >= 6) {
                    val target = nextClients.firstOrNull { it.id == clientId }
                    if (target != null) {
                        nextClients = listOf(target) + nextClients.filter { it.id != clientId }
                    }
                }
            }
            s.copy(activeClientId = clientId, clients = nextClients)
        }
    }

    fun togglePinClient(clientId: String) {
        updateAndSave { s ->
            s.copy(clients = s.clients.map { if (it.id == clientId) it.copy(pinned = !it.pinned) else it })
        }
    }

    fun deleteClient(clientId: String) {
        updateAndSave { s ->
            val rem = s.clients.filter { it.id != clientId }
            val nextActive = if (s.activeClientId == clientId) rem.firstOrNull()?.id ?: "" else s.activeClientId
            s.copy(clients = rem, activeClientId = nextActive)
        }
        showToast("Клиент удалён")
    }

    fun upsertClient(program: ClientProgram) {
        updateAndSave { s ->
            val exists = s.clients.any { it.id == program.id }
            val next = if (exists) s.clients.map { if (it.id == program.id) program else it } else listOf(program) + s.clients
            s.copy(clients = next, activeClientId = program.id)
        }
        showToast("Программа «${program.name}» сохранена")
    }

    fun setActiveWeek(week: Int) {
        val cid = activeClient()?.id ?: return
        updateAndSave { s ->
            s.copy(clients = s.clients.map { if (it.id == cid) it.copy(activeWeek = week.coerceIn(1, it.totalWeeks)) else it })
        }
    }

    fun setActiveDay(dayIndex: Int) {
        val cid = activeClient()?.id ?: return
        updateAndSave { s ->
            s.copy(
                clients = s.clients.map { if (it.id == cid) it.copy(activeDay = dayIndex) else it },
                focusExIndexByClient = s.focusExIndexByClient - cid
            )
        }
    }

    fun updateActiveExercise(exId: String, updater: (ExerciseWeekData) -> ExerciseWeekData) {
        val c = activeClient() ?: return
        val w = c.activeWeek
        val d = c.activeDay
        updateAndSave { s ->
            s.copy(clients = s.clients.map { cl ->
                if (cl.id != c.id) cl else {
                    val dayObj = cl.days[d] ?: return@map cl
                    val nextEx = dayObj.exercises.map { ex ->
                        if (ex.id != exId) ex else {
                            val cur = ex.weekData(w)
                            val updated = updater(cur)
                            ex.copy(weeks = ex.weeks + (w to updated))
                        }
                    }
                    cl.copy(days = cl.days + (d to dayObj.copy(exercises = nextEx)))
                }
            })
        }
    }

    fun completeExercise(exId: String) {
        val c = activeClient() ?: return
        val dayObj = c.currentDay() ?: return
        val ex = dayObj.exercises.firstOrNull { it.id == exId } ?: return
        updateActiveExercise(exId) { it.copy(status = "completed") }
        startOrToggleTimer(c.id, c.name, ex.name, ex.restSec, forceStart = true)
        // Auto-unpin if all exercises completed
        val updatedClient = activeClient()
        if (updatedClient != null && state.settings.pinMode && updatedClient.pinned) {
            val (done, total) = updatedClient.completedCount()
            if (total > 0 && done >= total) {
                togglePinClient(updatedClient.id)
            }
        }
    }

    fun skipExercise(exId: String) {
        updateActiveExercise(exId) { it.copy(status = "skipped") }
        showToast("Упражнение пропущено")
    }

    fun uncompleteExercise(exId: String) {
        updateActiveExercise(exId) { it.copy(status = "pending") }
    }

    fun startOrToggleTimer(clientId: String, clientName: String, exName: String, durationSec: Int, forceStart: Boolean = false) {
        val existing = state.timersByClient[clientId]
        val now = System.currentTimeMillis()
        nowMs = now
        if (!forceStart && existing != null && existing.running && existing.endTimeMs > now) {
            state = state.copy(timersByClient = state.timersByClient - clientId)
        } else {
            val sec = durationSec.coerceAtLeast(15)
            val timer = ClientTimerState(
                ownerClientId = clientId,
                ownerClientName = clientName,
                ownerExerciseName = exName,
                totalDurationSec = sec,
                endTimeMs = now + sec * 1000L,
                running = true
            )
            state = state.copy(timersByClient = state.timersByClient + (clientId to timer))
        }
    }

    private fun checkExpiredTimers(now: Long) {
        val expired = state.timersByClient.values.filter { it.running && it.endTimeMs <= now }
        if (expired.isEmpty()) return
        val nextMap = state.timersByClient.toMutableMap()
        val newAlerts = mutableListOf<TimerAlert>()
        for (t in expired) {
            nextMap.remove(t.ownerClientId)
            newAlerts.add(TimerAlert(clientId = t.ownerClientId, clientName = t.ownerClientName, exerciseName = t.ownerExerciseName))
        }
        state = state.copy(timersByClient = nextMap)
        timerAlerts = newAlerts + timerAlerts
        if (state.settings.timerSound) playBeep()
    }

    fun dismissAlert(alertId: String) {
        timerAlerts = timerAlerts.filter { it.id != alertId }
    }

    private fun playBeep() {
        try {
            if (toneGenerator == null) {
                toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
            }
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 320)
        } catch (_: Exception) {}
    }

    fun updateMeasurement(week: Int, field: String, value: String) {
        val c = activeClient() ?: return
        updateAndSave { s ->
            s.copy(clients = s.clients.map { cl ->
                if (cl.id != c.id) cl else {
                    val wkMap = (cl.measurements[week] ?: emptyMap()) + (field to value)
                    cl.copy(measurements = cl.measurements + (week to wkMap))
                }
            })
        }
    }

    fun setTheme(theme: AppThemeId) {
        updateAndSave { it.copy(theme = theme) }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        updateAndSave { it.copy(settings = transform(it.settings)) }
    }

    fun importBackupJson(jsonStr: String) {
        val parsed = FormaJsonCodec.fromJson(jsonStr)
        if (parsed != null) {
            state = parsed
            repo.saveLocalState(parsed)
            showToast("Бэкап восстановлен (${parsed.clients.size} кл.)")
        } else {
            showToast("Неверный формат файла бэкапа")
        }
    }

    fun signInSupabase(email: String, password: String, isSignUp: Boolean, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            val res = if (isSignUp) repo.supabaseSignUp(email, password) else repo.supabaseSignIn(email, password)
            if (res.success) {
                updateSettings {
                    it.copy(
                        sbAccessToken = res.accessToken,
                        sbRefreshToken = res.refreshToken,
                        sbUserId = res.userId,
                        sbUserEmail = res.email
                    )
                }
                showToast("Вход выполнен: ${res.email}")
                onDone(null)
            } else {
                onDone(res.error)
            }
        }
    }

    fun pushCloud() {
        viewModelScope.launch {
            val (ok, msg) = repo.pushToSupabase(state)
            if (ok) {
                updateSettings { it.copy(sbLastSyncAt = msg) }
                showToast("Синхронизировано в облако ($msg)")
            } else {
                showToast(msg)
            }
        }
    }

    fun pullCloud() {
        viewModelScope.launch {
            val (loaded, msg) = repo.pullFromSupabase(state.settings)
            if (loaded != null) {
                state = loaded
                repo.saveLocalState(loaded)
            }
            showToast(msg)
        }
    }

    fun logoutCloud() {
        updateSettings {
            it.copy(sbAccessToken = "", sbRefreshToken = "", sbUserId = "", sbUserEmail = "", sbLastSyncAt = "")
        }
        showToast("Вы вышли из облачного аккаунта")
    }

    override fun onCleared() {
        super.onCleared()
        try { toneGenerator?.release() } catch (_: Exception) {}
        toneGenerator = null
    }
}
