package com.fittrainer.live.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.fittrainer.live.model.*
import com.fittrainer.live.theme.LiquidGlassCard
import com.fittrainer.live.theme.LocalFormaPalette

@Composable
fun TablesTabContent(
    vm: FormaViewModel,
    onExportCsv: (ClientProgram) -> Unit,
    onOpenWorkouts: () -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalFormaPalette.current
    var pasteClientName by remember { mutableStateOf("") }
    var pasteBody by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text("Таблицы", color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                if (p.id == AppThemeId.NEWYEAR) Text(" 🎅", fontSize = 13.sp)
            }
        }

        // Paste cells card
        item {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Вставить скопированные ячейки", color = p.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.verticalGradient(listOf(p.accent, p.accentStrong)))
                                .clickable {
                                    val parsed = vm.repo.parsePastedCells(pasteClientName, pasteBody)
                                    if (parsed != null) {
                                        vm.upsertClient(parsed)
                                        pasteClientName = ""
                                        pasteBody = ""
                                        onOpenWorkouts()
                                    } else {
                                        vm.showToast("Вставьте строки таблицы из Excel или Google Sheets")
                                    }
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Добавить", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(p.wellBg)
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        BasicTextField(
                            value = pasteClientName,
                            onValueChange = { pasteClientName = it },
                            singleLine = true,
                            textStyle = TextStyle(color = p.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
                            cursorBrush = SolidColor(p.accent),
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { inner ->
                                if (pasteClientName.isEmpty()) Text("Имя клиента...", color = p.textMuted, fontSize = 12.sp)
                                inner()
                            }
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(84.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(p.wellBg)
                            .padding(10.dp)
                    ) {
                        BasicTextField(
                            value = pasteBody,
                            onValueChange = { pasteBody = it },
                            textStyle = TextStyle(color = p.textPrimary, fontSize = 11.5.sp),
                            cursorBrush = SolidColor(p.accent),
                            modifier = Modifier.fillMaxSize(),
                            decorationBox = { inner ->
                                if (pasteBody.isEmpty()) Text("Понедельник\tПриседания\t8-10\t2 мин\t4x RPE 8\t60", color = p.textMuted, fontSize = 11.sp)
                                inner()
                            }
                        )
                    }
                }
            }
        }

        // Connected Programs
        item {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Подключённые программы", color = p.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    vm.state.clients.forEach { cl ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(p.wellBg)
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                Text(cl.name, color = p.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(cl.days.values.joinToString(", ") { it.name }, color = p.textSecondary, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(p.cardBg)
                                        .border(1.dp, p.cardBorder, RoundedCornerShape(10.dp))
                                        .clickable { onExportCsv(cl) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(".csv", color = p.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(p.accentPillBg)
                                        .border(1.dp, p.accentBorder, RoundedCornerShape(10.dp))
                                        .clickable {
                                            vm.selectClient(cl.id)
                                            onOpenWorkouts()
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("Открыть", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClientsTabContent(
    vm: FormaViewModel,
    onOpenWorkouts: () -> Unit,
    onEditClient: (ClientProgram) -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalFormaPalette.current
    var query by remember { mutableStateOf("") }
    var menuClient by remember { mutableStateOf<ClientProgram?>(null) }

    val filtered = remember(vm.state.clients, query) {
        if (query.isBlank()) vm.state.clients
        else vm.state.clients.filter { cl ->
            cl.name.contains(query, ignoreCase = true) ||
                cl.days.values.any { it.name.contains(query, ignoreCase = true) }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text("База клиентов", color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                if (p.id == AppThemeId.NEWYEAR) Text(" 🎅", fontSize = 13.sp)
            }
        }

        item {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("База клиентов", color = p.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Управление программами и быстрый переход", color = p.textSecondary, fontSize = 11.sp)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(p.accentPillBg)
                                .border(1.dp, p.accentBorder, RoundedCornerShape(14.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text("• ${vm.state.clients.size} клиентов", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    // Search Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(p.wellBg)
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Search, contentDescription = null, tint = p.textMuted, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = p.textPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold),
                            cursorBrush = SolidColor(p.accent),
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { inner ->
                                if (query.isEmpty()) Text("Поиск клиента по имени или дню...", color = p.textMuted, fontSize = 12.sp)
                                inner()
                            }
                        )
                    }

                    // Client rows
                    filtered.forEach { cl ->
                        val activeDayName = cl.currentDay()?.name ?: "День ${cl.activeDay}"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(p.wellBg)
                                .border(0.8.dp, p.cardBorder, RoundedCornerShape(16.dp))
                                .clickable {
                                    vm.selectClient(cl.id)
                                    onOpenWorkouts()
                                }
                                .padding(horizontal = 12.dp, vertical = 11.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                Text(cl.name, color = p.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("Неделя ${cl.activeWeek}/${cl.totalWeeks} • $activeDayName", color = p.textSecondary, fontSize = 11.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(p.cardBg)
                                    .border(1.dp, p.cardBorder, RoundedCornerShape(12.dp))
                                    .clickable { menuClient = cl }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Меню ...", color = p.textPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    menuClient?.let { cl ->
        Dialog(onDismissRequest = { menuClient = null }) {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth(), strong = true) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(cl.name, color = p.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                    ModalActionRow("🏋️ Открыть тренировку") {
                        vm.selectClient(cl.id)
                        menuClient = null
                        onOpenWorkouts()
                    }
                    ModalActionRow("✏️ Редактировать в конструкторе") {
                        menuClient = null
                        onEditClient(cl)
                    }
                    ModalActionRow(if (cl.pinned) "📌 Открепить карточку" else "📌 Закрепить карточку") {
                        vm.togglePinClient(cl.id)
                        menuClient = null
                    }
                    ModalActionRow("🗑 Удалить клиента", danger = true) {
                        vm.deleteClient(cl.id)
                        menuClient = null
                    }
                }
            }
        }
    }
}

@Composable
private fun ModalActionRow(title: String, danger: Boolean = false, onClick: () -> Unit) {
    val p = LocalFormaPalette.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(p.wellBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(
            text = title,
            color = if (danger) Color(0xFFFB7185) else p.textPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun SettingsTabContent(
    vm: FormaViewModel,
    onExportJsonBackup: () -> Unit,
    onImportJsonBackup: () -> Unit,
    modifier: Modifier = Modifier
) {
    val p = LocalFormaPalette.current
    val settings = vm.state.settings
    var showThemeModal by remember { mutableStateOf(false) }
    var showAuthModal by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text("Настройки", color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                if (p.id == AppThemeId.NEWYEAR) Text(" 🎅", fontSize = 13.sp)
            }
        }

        // 1. Supabase Cloud Account Card
        item {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("☁️ Облачный аккаунт", color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                            Text(
                                text = settings.sbUserEmail.ifBlank { "Не подключен (локальный режим)" },
                                color = p.textSecondary,
                                fontSize = 11.5.sp
                            )
                        }
                        if (settings.sbAccessToken.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(p.accentPillBg)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("• Облако • ${vm.state.clients.size} кл.", color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }

                    if (settings.sbAccessToken.isBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Brush.verticalGradient(listOf(p.accent, p.accentStrong)))
                                .clickable { showAuthModal = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Войти / Регистрация", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    } else {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Brush.verticalGradient(listOf(p.accent, p.accentStrong)))
                                    .clickable { vm.pushCloud() },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("⬆️ В облако", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(p.accentPillBg)
                                    .border(1.dp, p.accentBorder, RoundedCornerShape(14.dp))
                                    .clickable { vm.pullCloud() },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("⬇️ Из облака", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = if (settings.sbLastSyncAt.isNotBlank()) "Синхронизировано: ${settings.sbLastSyncAt}" else "Готов к синхронизации",
                                color = p.textSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Выйти",
                                color = Color(0xFFFB7185),
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { vm.logoutCloud() }
                            )
                        }
                    }
                }
            }
        }

        // 2. Brand Card (Forma Pro v3.0 Kotlin • #015)
        item {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.verticalGradient(listOf(Color(0xFFFB923C), Color(0xFFEA580C)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.FitnessCenter, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Forma Pro", color = p.textPrimary, fontSize = 15.5.sp, fontWeight = FontWeight.ExtraBold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(p.accentPillBg)
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text("v3.0 Kotlin • #015", color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Text("Нативный 120Hz движок • Jetpack Compose", color = p.textSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        // 3. Single-Button Theme Picker Card
        item {
            LiquidGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showThemeModal = true }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("🎨 Тема оформления", color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Нажмите, чтобы выбрать палитру", color = p.textSecondary, fontSize = 11.sp)
                    }
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(p.wellBg)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(vm.state.theme.label, color = p.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = p.textMuted, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // 4. App Settings Toggles
        item {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Настройки приложения", color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    SettingToggleRow("✨ Мягкая сортировка", "Сегодняшние клиенты в начале списка", settings.softSorting) {
                        vm.updateSettings { it.copy(softSorting = !it.softSorting) }
                    }
                    SettingToggleRow("📌 Режим закрепа", "Долгое нажатие закрепляет карточку клиента", settings.pinMode) {
                        vm.updateSettings { it.copy(pinMode = !it.pinMode) }
                    }
                    SettingToggleRow("↕ Скрывать нижний бар", "Прятать меню при прокрутке вниз", settings.autoHideBottomBar) {
                        vm.updateSettings { it.copy(autoHideBottomBar = !it.autoHideBottomBar) }
                    }
                    SettingToggleRow("🔔 Звук таймера", "Сигнал по окончании отдыха", settings.timerSound) {
                        vm.updateSettings { it.copy(timerSound = !it.timerSound) }
                    }
                }
            }
        }

        // 5. Local Backup & Restore (.json)
        item {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("💾 Локальная копия (.json)", color = p.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(p.wellBg)
                                .border(1.dp, p.cardBorder, RoundedCornerShape(14.dp))
                                .clickable { onExportJsonBackup() },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("📤 Сохранить .json", color = p.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(p.accentPillBg)
                                .border(1.dp, p.accentBorder, RoundedCornerShape(14.dp))
                                .clickable { onImportJsonBackup() },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("📥 Восстановить", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }

    // 6-Theme Picker Dialog
    if (showThemeModal) {
        Dialog(onDismissRequest = { showThemeModal = false }) {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth(), strong = true) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Тема оформления", color = p.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                        IconButton(onClick = { showThemeModal = false }, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Rounded.Close, contentDescription = null, tint = p.textSecondary)
                        }
                    }
                    AppThemeId.values().toList().chunked(2).forEach { pair ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { t ->
                                val selected = vm.state.theme == t
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (selected) p.accentPillBg else p.wellBg)
                                        .border(if (selected) 1.5.dp else 1.dp, if (selected) p.accentBorder else p.cardBorder, RoundedCornerShape(14.dp))
                                        .clickable {
                                            vm.setTheme(t)
                                            showThemeModal = false
                                        }
                                        .padding(horizontal = 10.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Text(t.label, color = if (selected) p.accent else p.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Supabase Auth Dialog
    if (showAuthModal) {
        SupabaseAuthDialog(vm = vm, onDismiss = { showAuthModal = false })
    }
}

@Composable
private fun SettingToggleRow(title: String, subtitle: String, checked: Boolean, onToggle: () -> Unit) {
    val p = LocalFormaPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(p.wellBg)
            .clickable { onToggle() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = p.textPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, color = p.textSecondary, fontSize = 10.5.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = p.accent
            )
        )
    }
}

@Composable
private fun SupabaseAuthDialog(vm: FormaViewModel, onDismiss: () -> Unit) {
    val p = LocalFormaPalette.current
    var email by remember { mutableStateOf(vm.state.settings.sbUserEmail) }
    var password by remember { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var isSignUp by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var errMsg by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        LiquidGlassCard(modifier = Modifier.fillMaxWidth(), strong = true) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("☁️ Вход в Forma Pro", color = p.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.wellBg)
                        .padding(3.dp)
                ) {
                    listOf(false to "Войти", true to "Регистрация").forEach { (mode, label) ->
                        val active = isSignUp == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (active) p.accentPillBg else Color.Transparent)
                                .clickable { isSignUp = mode },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, color = if (active) p.accent else p.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.wellBg)
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    BasicTextField(
                        value = email,
                        onValueChange = { email = it },
                        singleLine = true,
                        textStyle = TextStyle(color = p.textPrimary, fontSize = 13.sp),
                        cursorBrush = SolidColor(p.accent),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { inner ->
                            if (email.isEmpty()) Text("Email", color = p.textMuted, fontSize = 13.sp)
                            inner()
                        }
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.wellBg)
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = password,
                        onValueChange = { password = it },
                        singleLine = true,
                        visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                        textStyle = TextStyle(color = p.textPrimary, fontSize = 13.sp),
                        cursorBrush = SolidColor(p.accent),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            if (password.isEmpty()) Text("Пароль", color = p.textMuted, fontSize = 13.sp)
                            inner()
                        }
                    )
                    IconButton(onClick = { showPass = !showPass }, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = if (showPass) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                            contentDescription = null,
                            tint = p.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                if (errMsg != null) {
                    Text(errMsg!!, color = Color(0xFFFB7185), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Brush.verticalGradient(listOf(p.accent, p.accentStrong)))
                        .clickable(enabled = !loading) {
                            if (email.isBlank() || password.length < 6) {
                                errMsg = "Введите email и пароль (от 6 символов)"
                                return@clickable
                            }
                            loading = true
                            errMsg = null
                            vm.signInSupabase(email, password, isSignUp) { err ->
                                loading = false
                                if (err == null) onDismiss() else errMsg = err
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (loading) "Подключение..." else if (isSignUp) "Создать аккаунт" else "Войти",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}
