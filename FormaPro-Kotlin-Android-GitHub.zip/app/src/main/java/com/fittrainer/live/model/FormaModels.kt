package com.fittrainer.live.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import kotlin.math.roundToInt

enum class AppThemeId(val key: String, val label: String, val isDark: Boolean, val statusBarHex: String) {
    DAY("day", "☀️ Дневной", false, "#EEF1F6"),
    NIGHT("night", "🌙 Ночной", true, "#0C131D"),
    SAGE("sage", "🌿 Шалфей", false, "#EDF3F0"),
    OBSIDIAN("obsidian", "⚡ Обсидиан", true, "#0C0D12"),
    BURGUNDY("burgundy", "🍷 Бургунди", true, "#541930"),
    NEWYEAR("newyear", "🎄 Новогодний", true, "#0A221D");

    companion object {
        fun fromKey(k: String?): AppThemeId = values().firstOrNull { it.key == k } ?: NEWYEAR
    }
}

data class ExerciseWeekData(
    val sets: Int = 3,
    val reps: String = "10-12",
    val rpe: Int = 8,
    val weight: String = "",
    val status: String = "pending"
)

data class ExerciseItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val restSec: Int = 120,
    val intensifier: String = "",
    val supersetGroup: String = "",
    val weeks: Map<Int, ExerciseWeekData> = mapOf(1 to ExerciseWeekData())
) {
    fun weekData(week: Int): ExerciseWeekData = weeks[week] ?: weeks[1] ?: ExerciseWeekData()
}

data class WorkoutDay(
    val dayIndex: Int,
    val name: String,
    val exercises: List<ExerciseItem> = emptyList()
)

data class ClientProgram(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val totalWeeks: Int = 6,
    val activeWeek: Int = 1,
    val activeDay: Int = 1,
    val pinned: Boolean = false,
    val days: Map<Int, WorkoutDay> = emptyMap(),
    val measurements: Map<Int, Map<String, String>> = emptyMap()
) {
    fun currentDay(): WorkoutDay? = days[activeDay] ?: days.values.firstOrNull()

    fun completedCount(week: Int = activeWeek, day: Int = activeDay): Pair<Int, Int> {
        val d = days[day] ?: days.values.firstOrNull() ?: return 0 to 0
        val done = d.exercises.count { it.weekData(week).status == "completed" }
        return done to d.exercises.size
    }
}

data class ClientTimerState(
    val ownerClientId: String,
    val ownerClientName: String,
    val ownerExerciseName: String,
    val totalDurationSec: Int,
    val endTimeMs: Long,
    val running: Boolean = true
)

data class TimerAlert(
    val id: String = UUID.randomUUID().toString(),
    val clientId: String,
    val clientName: String,
    val exerciseName: String,
    val createdAtMs: Long = System.currentTimeMillis()
)

data class AppSettings(
    val softSorting: Boolean = true,
    val pinMode: Boolean = false,
    val autoHideBottomBar: Boolean = false,
    val timerSound: Boolean = true,
    val sbAccessToken: String = "",
    val sbRefreshToken: String = "",
    val sbUserId: String = "",
    val sbUserEmail: String = "",
    val sbLastSyncAt: String = ""
)

data class AppState(
    val theme: AppThemeId = AppThemeId.NEWYEAR,
    val activeTab: Int = 2,
    val activeClientId: String = "",
    val clients: List<ClientProgram> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val timersByClient: Map<String, ClientTimerState> = emptyMap(),
    val focusExIndexByClient: Map<String, Int> = emptyMap()
)

object TonnageMath {
    private val plusRegex = Regex("(\\d+(?:[.,]\\d+)?)\\s*\\+\\s*(\\d+(?:[.,]\\d+)?)")
    private val numRegex = Regex("\\d+(?:[.,]\\d+)?")
    private val rangeRegex = Regex("(\\d+)\\s*[-–—]\\s*(\\d+)")
    private val intRegex = Regex("\\d+")

    fun parseWeightKg(raw: String?): Double {
        val s = (raw ?: "").trim().uppercase()
        if (s.isEmpty() || s == "BW" || s == "СВ" || s == "-") return 0.0
        val plusMatch = plusRegex.find(s)
        if (plusMatch != null) {
            val a = plusMatch.groupValues[1].replace(',', '.').toDoubleOrNull() ?: 0.0
            val b = plusMatch.groupValues[2].replace(',', '.').toDoubleOrNull() ?: 0.0
            return a + b
        }
        return numRegex.find(s)?.value?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
    }

    fun parseAvgReps(raw: String?): Double {
        val s = (raw ?: "").trim()
        val range = rangeRegex.find(s)
        if (range != null) {
            val a = range.groupValues[1].toDoubleOrNull() ?: 10.0
            val b = range.groupValues[2].toDoubleOrNull() ?: a
            return (a + b) / 2.0
        }
        return intRegex.find(s)?.value?.toDoubleOrNull() ?: 10.0
    }

    fun computeDayTonnageKg(day: WorkoutDay?, week: Int): Int {
        if (day == null) return 0
        var sum = 0.0
        for (ex in day.exercises) {
            val wd = ex.weekData(week)
            val w = parseWeightKg(wd.weight)
            if (w > 0.0) {
                sum += w * wd.sets.coerceAtLeast(1) * parseAvgReps(wd.reps)
            }
        }
        return sum.roundToInt()
    }

    fun computeDaySetsCount(day: WorkoutDay?, week: Int): Int {
        if (day == null) return 0
        return day.exercises.sumOf { it.weekData(week).sets.coerceAtLeast(1) }
    }

    fun clientHasWorkoutToday(client: ClientProgram): Boolean {
        val cal = Calendar.getInstance()
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val keywords = when (dow) {
            Calendar.MONDAY -> listOf("понед", "пн")
            Calendar.TUESDAY -> listOf("вторн", "вт")
            Calendar.WEDNESDAY -> listOf("сред", "ср")
            Calendar.THURSDAY -> listOf("четв", "чт")
            Calendar.FRIDAY -> listOf("пятн", "пт")
            Calendar.SATURDAY -> listOf("субб", "сб")
            Calendar.SUNDAY -> listOf("воскр", "вс")
            else -> emptyList()
        }
        return client.days.values.any { d ->
            val n = d.name.lowercase()
            keywords.any { kw -> n.contains(kw) }
        }
    }
}

object ProExerciseLibrary {
    val muscleGroups: List<Pair<String, List<String>>> = listOf(
        "Ягодицы" to listOf(
            "Ягодичный мост со штангой",
            "Румынская тяга с гантелями",
            "Болгарские выпады с гантелями",
            "Отведение ноги назад в кроссовере",
            "Разведение ног в тренажёре (в наклоне)",
            "Гиперэкстензия с акцентом на ягодицы",
            "Приседания Сумо (Плие) с гантелью"
        ),
        "Ноги" to listOf(
            "Приседания со штангой на спине",
            "Жим ногами в тренажёре",
            "Гакк-приседания",
            "Разгибание ног сидя в тренажёре",
            "Сгибание ног лёжа в тренажёре",
            "Подъём на носки стоя в тренажёре"
        ),
        "Спина" to listOf(
            "Подтягивания широким хватом",
            "Тяга верхнего блока широким хватом",
            "Тяга Т-грифа с упором в грудь",
            "Горизонтальная тяга к поясу",
            "Тяга гантели в наклоне одной рукой",
            "Пулловер в кроссовере с канатом"
        ),
        "Грудь" to listOf(
            "Жим штанги лёжа",
            "Жим гантелей на наклонной скамье 30°",
            "Сведение рук в тренажёре «Бабочка»",
            "Отжимания на брусьях",
            "Кроссовер с верхних блоков"
        ),
        "Плечи" to listOf(
            "Жим гантелей сидя",
            "Армейский жим штанги стоя",
            "Махи гантелями в стороны",
            "Тяга каната к лицу (Face Pull)",
            "Обратная бабочка (задняя дельта)"
        ),
        "Руки" to listOf(
            "Подъём штанги на бицепс стоя",
            "Молотки с гантелями",
            "Разгибание рук на блоке с канатом",
            "Французский жим лёжа с EZ-штангой"
        ),
        "Кор" to listOf(
            "Скручивания на верхнем блоке",
            "Подъём ног в висе",
            "Планка классическая",
            "Вакуум живота"
        )
    )

    fun createDemoClients(): List<ClientProgram> {
        fun makeWeeks(sets: Int, reps: String, rpe: Int, w1: String = "", w2: String = ""): Map<Int, ExerciseWeekData> =
            (1..6).associateWith { wk ->
                ExerciseWeekData(
                    sets = sets,
                    reps = reps,
                    rpe = rpe,
                    weight = when (wk) {
                        1 -> w1
                        2 -> w2
                        else -> ""
                    }
                )
            }

        val c1 = ClientProgram(
            id = "demo_sergey",
            name = "Сергей",
            totalWeeks = 6,
            activeWeek = 2,
            activeDay = 1,
            days = mapOf(
                1 to WorkoutDay(1, "Понедельник", listOf(
                    ExerciseItem("e1", "Приседания со штангой на спине", 180, weeks = makeWeeks(4, "6-8", 8, "80", "85")),
                    ExerciseItem("e2", "Румынская тяга со штангой", 150, weeks = makeWeeks(4, "8-10", 8, "70", "75")),
                    ExerciseItem("e3", "Жим ногами в тренажёре", 120, weeks = makeWeeks(4, "10-12", 8, "140", "150")),
                    ExerciseItem("e4", "Разгибание ног сидя в тренажёре", 90, weeks = makeWeeks(3, "12-15", 8, "45", "50"))
                )),
                2 to WorkoutDay(2, "Среда", listOf(
                    ExerciseItem("e5", "Жим штанги лёжа", 180, weeks = makeWeeks(4, "6-8", 8, "75", "80")),
                    ExerciseItem("e6", "Тяга верхнего блока широким хватом", 120, weeks = makeWeeks(4, "8-10", 8, "55", "60")),
                    ExerciseItem("e7", "Жим гантелей на наклонной скамье 30°", 120, weeks = makeWeeks(3, "10-12", 8, "24+24", "26+26"))
                )),
                3 to WorkoutDay(3, "Пятница", listOf(
                    ExerciseItem("e8", "Подтягивания широким хватом", 150, weeks = makeWeeks(4, "8-10", 8, "BW", "BW")),
                    ExerciseItem("e9", "Жим гантелей сидя", 120, weeks = makeWeeks(4, "10-12", 8, "18+18", "20+20")),
                    ExerciseItem("e10", "Махи гантелями в стороны", 90, weeks = makeWeeks(4, "12-15", 9, "10+10", "12+12"))
                ))
            )
        )

        val c2 = ClientProgram(
            id = "demo_aminat",
            name = "Аминат",
            totalWeeks = 6,
            activeWeek = 1,
            activeDay = 1,
            days = mapOf(
                1 to WorkoutDay(1, "Понедельник", listOf(
                    ExerciseItem("a1", "Ягодичный мост со штангой", 120, weeks = makeWeeks(4, "10-12", 8, "55")),
                    ExerciseItem("a2", "Приседания Сумо (Плие) с гантелью", 90, weeks = makeWeeks(3, "10-12", 8, "30")),
                    ExerciseItem("a3", "Отведение ноги назад в кроссовере", 60, weeks = makeWeeks(3, "12-15", 8, "15"))
                )),
                2 to WorkoutDay(2, "Среда", listOf(
                    ExerciseItem("a4", "Тяга верхнего блока широким хватом", 90, weeks = makeWeeks(3, "10-12", 8, "32")),
                    ExerciseItem("a5", "Горизонтальная тяга к поясу", 90, weeks = makeWeeks(3, "10-12", 8, "32"))
                )),
                3 to WorkoutDay(3, "Пятница", listOf(
                    ExerciseItem("a6", "Болгарские выпады с гантелями", 90, weeks = makeWeeks(3, "10-12", 8, "12+12")),
                    ExerciseItem("a7", "Гиперэкстензия с акцентом на ягодицы", 90, weeks = makeWeeks(3, "12-15", 8, "10"))
                ))
            )
        )

        return listOf(c1, c2)
    }
}

object FormaJsonCodec {
    private val TAB_KEYS = listOf("tables", "clients", "workouts", "analytics", "profile")

    fun toJson(state: AppState): String {
        val root = JSONObject()
        root.put("theme", state.theme.key)
        root.put("activeTab", TAB_KEYS.getOrElse(state.activeTab) { "workouts" })
        root.put("activeClientId", state.activeClientId)

        val sObj = JSONObject()
        sObj.put("softSorting", state.settings.softSorting)
        sObj.put("pinMode", state.settings.pinMode)
        sObj.put("autoHideBottomBar", state.settings.autoHideBottomBar)
        sObj.put("timerSound", state.settings.timerSound)
        sObj.put("sbAccessToken", state.settings.sbAccessToken)
        sObj.put("sbRefreshToken", state.settings.sbRefreshToken)
        sObj.put("sbUserId", state.settings.sbUserId)
        sObj.put("sbUserEmail", state.settings.sbUserEmail)
        sObj.put("sbLastSyncAt", state.settings.sbLastSyncAt)
        root.put("settings", sObj)

        val cArr = JSONArray()
        for (c in state.clients) {
            val cObj = JSONObject()
            cObj.put("id", c.id)
            cObj.put("name", c.name)
            cObj.put("totalWeeks", c.totalWeeks)
            cObj.put("activeWeek", c.activeWeek)
            cObj.put("activeDay", c.activeDay)
            cObj.put("pinned", c.pinned)

            val daysObj = JSONObject()
            for ((dIdx, day) in c.days) {
                val dObj = JSONObject()
                dObj.put("name", day.name)
                val exArr = JSONArray()
                for (ex in day.exercises) {
                    val eObj = JSONObject()
                    eObj.put("id", ex.id)
                    eObj.put("name", ex.name)
                    eObj.put("restSec", ex.restSec)
                    eObj.put("intensifier", ex.intensifier)
                    eObj.put("supersetGroup", ex.supersetGroup)
                    val wObj = JSONObject()
                    for ((wk, wd) in ex.weeks) {
                        val wdObj = JSONObject()
                        wdObj.put("sets", wd.sets)
                        wdObj.put("reps", wd.reps)
                        wdObj.put("rpe", wd.rpe)
                        wdObj.put("weight", wd.weight)
                        wdObj.put("status", wd.status)
                        wObj.put(wk.toString(), wdObj)
                    }
                    eObj.put("weeks", wObj)
                    exArr.put(eObj)
                }
                dObj.put("exercises", exArr)
                daysObj.put(dIdx.toString(), dObj)
            }
            cObj.put("days", daysObj)

            val mObj = JSONObject()
            for ((wk, fields) in c.measurements) {
                val fObj = JSONObject()
                for ((k, v) in fields) fObj.put(k, v)
                mObj.put(wk.toString(), fObj)
            }
            cObj.put("measurements", mObj)
            cArr.put(cObj)
        }
        root.put("clients", cArr)
        return root.toString()
    }

    fun fromJson(jsonStr: String): AppState? {
        return try {
            val root = JSONObject(jsonStr)
            val theme = AppThemeId.fromKey(root.optString("theme", "newyear"))
            val tabKey = root.optString("activeTab", "workouts")
            val activeTab = TAB_KEYS.indexOf(tabKey).takeIf { it >= 0 } ?: 2
            val activeClientId = root.optString("activeClientId", "")

            val sObj = root.optJSONObject("settings")
            val settings = if (sObj != null) {
                AppSettings(
                    softSorting = sObj.optBoolean("softSorting", true),
                    pinMode = sObj.optBoolean("pinMode", false),
                    autoHideBottomBar = sObj.optBoolean("autoHideBottomBar", false),
                    timerSound = sObj.optBoolean("timerSound", true),
                    sbAccessToken = sObj.optString("sbAccessToken", ""),
                    sbRefreshToken = sObj.optString("sbRefreshToken", ""),
                    sbUserId = sObj.optString("sbUserId", ""),
                    sbUserEmail = sObj.optString("sbUserEmail", ""),
                    sbLastSyncAt = sObj.optString("sbLastSyncAt", "")
                )
            } else AppSettings()

            val clients = mutableListOf<ClientProgram>()
            val cArr = root.optJSONArray("clients")
            if (cArr != null) {
                for (i in 0 until cArr.length()) {
                    val cObj = cArr.optJSONObject(i) ?: continue
                    val days = mutableMapOf<Int, WorkoutDay>()
                    val daysObj = cObj.optJSONObject("days")
                    if (daysObj != null) {
                        val keys = daysObj.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            val dIdx = k.toIntOrNull() ?: continue
                            val dObj = daysObj.optJSONObject(k) ?: continue
                            val exList = mutableListOf<ExerciseItem>()
                            val exArr = dObj.optJSONArray("exercises")
                            if (exArr != null) {
                                for (j in 0 until exArr.length()) {
                                    val eObj = exArr.optJSONObject(j) ?: continue
                                    val weeksMap = mutableMapOf<Int, ExerciseWeekData>()
                                    val wObj = eObj.optJSONObject("weeks")
                                    if (wObj != null) {
                                        val wKeys = wObj.keys()
                                        while (wKeys.hasNext()) {
                                            val wkStr = wKeys.next()
                                            val wk = wkStr.toIntOrNull() ?: continue
                                            val wdObj = wObj.optJSONObject(wkStr) ?: continue
                                            weeksMap[wk] = ExerciseWeekData(
                                                sets = wdObj.optInt("sets", 3),
                                                reps = wdObj.optString("reps", "10-12"),
                                                rpe = wdObj.optInt("rpe", 8),
                                                weight = wdObj.optString("weight", ""),
                                                status = wdObj.optString("status", "pending")
                                            )
                                        }
                                    }
                                    if (weeksMap.isEmpty()) weeksMap[1] = ExerciseWeekData()
                                    exList.add(
                                        ExerciseItem(
                                            id = eObj.optString("id", UUID.randomUUID().toString()),
                                            name = eObj.optString("name", "Упражнение"),
                                            restSec = eObj.optInt("restSec", 120),
                                            intensifier = eObj.optString("intensifier", ""),
                                            supersetGroup = eObj.optString("supersetGroup", ""),
                                            weeks = weeksMap
                                        )
                                    )
                                }
                            }
                            days[dIdx] = WorkoutDay(dIdx, dObj.optString("name", "День $dIdx"), exList)
                        }
                    }

                    val measMap = mutableMapOf<Int, Map<String, String>>()
                    val mObj = cObj.optJSONObject("measurements")
                    if (mObj != null) {
                        val mKeys = mObj.keys()
                        while (mKeys.hasNext()) {
                            val wkStr = mKeys.next()
                            val wk = wkStr.toIntOrNull() ?: continue
                            val fObj = mObj.optJSONObject(wkStr) ?: continue
                            val fMap = mutableMapOf<String, String>()
                            val fKeys = fObj.keys()
                            while (fKeys.hasNext()) {
                                val fk = fKeys.next()
                                fMap[fk] = fObj.optString(fk, "")
                            }
                            measMap[wk] = fMap
                        }
                    }

                    clients.add(
                        ClientProgram(
                            id = cObj.optString("id", UUID.randomUUID().toString()),
                            name = cObj.optString("name", "Клиент"),
                            totalWeeks = cObj.optInt("totalWeeks", 6).coerceIn(1, 12),
                            activeWeek = cObj.optInt("activeWeek", 1).coerceAtLeast(1),
                            activeDay = cObj.optInt("activeDay", 1).coerceAtLeast(1),
                            pinned = cObj.optBoolean("pinned", false),
                            days = days.toSortedMap(),
                            measurements = measMap
                        )
                    )
                }
            }

            val resolvedClients = clients.ifEmpty { ProExerciseLibrary.createDemoClients() }
            val resolvedActive = if (resolvedClients.any { it.id == activeClientId }) activeClientId else resolvedClients.first().id

            AppState(
                theme = theme,
                activeTab = activeTab,
                activeClientId = resolvedActive,
                clients = resolvedClients,
                settings = settings
            )
        } catch (_: Exception) {
            null
        }
    }
}
