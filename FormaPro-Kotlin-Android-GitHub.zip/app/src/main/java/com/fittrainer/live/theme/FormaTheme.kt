package com.fittrainer.live.theme

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.fittrainer.live.model.AppThemeId
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

data class FormaPalette(
    val id: AppThemeId,
    val bgTop: Color,
    val bgBottom: Color,
    val glowPrimary: Color,
    val glowSecondary: Color,
    val cardBg: Color,
    val cardStrongBg: Color,
    val wellBg: Color,
    val cardBorder: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val accent: Color,
    val accentStrong: Color,
    val accentPillBg: Color,
    val accentBorder: Color,
    val navBg: Color,
    val todayDot: Color
)

fun paletteFor(id: AppThemeId): FormaPalette = when (id) {
    AppThemeId.DAY -> FormaPalette(
        id = id,
        bgTop = Color(0xFFF3F5F9),
        bgBottom = Color(0xFFE6EBF4),
        glowPrimary = Color(0x262AABEE),
        glowSecondary = Color(0x1A007AFF),
        cardBg = Color(0xD6FFFFFF),
        cardStrongBg = Color(0xF5FFFFFF),
        wellBg = Color(0xC2E8EEF7),
        cardBorder = Color(0x140F172A),
        textPrimary = Color(0xFF0F172A),
        textSecondary = Color(0xFF475569),
        textMuted = Color(0xFF64748B),
        accent = Color(0xFF2AABEE),
        accentStrong = Color(0xFF168ACD),
        accentPillBg = Color(0x292AABEE),
        accentBorder = Color(0x752AABEE),
        navBg = Color(0xCCFFFFFF),
        todayDot = Color(0xFF10B981)
    )
    AppThemeId.NIGHT -> FormaPalette(
        id = id,
        bgTop = Color(0xFF0D1520),
        bgBottom = Color(0xFF090E16),
        glowPrimary = Color(0x292AABEE),
        glowSecondary = Color(0x2E1E508C),
        cardBg = Color(0xBD182434),
        cardStrongBg = Color(0xE81F2E42),
        wellBg = Color(0xC7101926),
        cardBorder = Color(0x29FFFFFF),
        textPrimary = Color(0xFFF1F5F9),
        textSecondary = Color(0xFF94A3B8),
        textMuted = Color(0xFF64748B),
        accent = Color(0xFF38BDF8),
        accentStrong = Color(0xFF1E88E5),
        accentPillBg = Color(0x3338BDF8),
        accentBorder = Color(0x8538BDF8),
        navBg = Color(0xD9101925),
        todayDot = Color(0xFF38BDF8)
    )
    AppThemeId.SAGE -> FormaPalette(
        id = id,
        bgTop = Color(0xFFF2F7F4),
        bgBottom = Color(0xFFE4EDE8),
        glowPrimary = Color(0x2410B981),
        glowSecondary = Color(0x1C14B8A6),
        cardBg = Color(0xD6FFFFFF),
        cardStrongBg = Color(0xF5FFFFFF),
        wellBg = Color(0xC2E2ECE7),
        cardBorder = Color(0x140F281E),
        textPrimary = Color(0xFF0F2922),
        textSecondary = Color(0xFF3F6259),
        textMuted = Color(0xFF648279),
        accent = Color(0xFF10B981),
        accentStrong = Color(0xFF0D9488),
        accentPillBg = Color(0x2910B981),
        accentBorder = Color(0x7310B981),
        navBg = Color(0xCCFAFDFB),
        todayDot = Color(0xFF0D9488)
    )
    AppThemeId.OBSIDIAN -> FormaPalette(
        id = id,
        bgTop = Color(0xFF101218),
        bgBottom = Color(0xFF090A0E),
        glowPrimary = Color(0x26F97316),
        glowSecondary = Color(0x1FEA580C),
        cardBg = Color(0xC71A1C24),
        cardStrongBg = Color(0xEB222530),
        wellBg = Color(0xD1111319),
        cardBorder = Color(0x1FFFFFFF),
        textPrimary = Color(0xFFF8FAFC),
        textSecondary = Color(0xFFA1A1AA),
        textMuted = Color(0xFF71717A),
        accent = Color(0xFFF97316),
        accentStrong = Color(0xFFEA580C),
        accentPillBg = Color(0x33F97316),
        accentBorder = Color(0x8CF97316),
        navBg = Color(0xD912141B),
        todayDot = Color(0xFFFB923C)
    )
    AppThemeId.BURGUNDY -> FormaPalette(
        id = id,
        bgTop = Color(0xFF611D38),
        bgBottom = Color(0xFF3B1021),
        glowPrimary = Color(0x47F43F5E),
        glowSecondary = Color(0x38E11D48),
        cardBg = Color(0xBA6C223F),
        cardStrongBg = Color(0xE67C2849),
        wellBg = Color(0xC44A152A),
        cardBorder = Color(0x3DFDA4AF),
        textPrimary = Color(0xFFFFF6F8),
        textSecondary = Color(0xFFF5CBD8),
        textMuted = Color(0xFFDFA0B5),
        accent = Color(0xFFFDA4AF),
        accentStrong = Color(0xFFE11D48),
        accentPillBg = Color(0x38FDA4AF),
        accentBorder = Color(0x8AFDA4AF),
        navBg = Color(0xD94A152A),
        todayDot = Color(0xFFFDA4AF)
    )
    AppThemeId.NEWYEAR -> FormaPalette(
        id = id,
        bgTop = Color(0xFF0D2B24),
        bgBottom = Color(0xFF071714),
        glowPrimary = Color(0x29FBBF24),
        glowSecondary = Color(0x3810B981),
        cardBg = Color(0xC20F2E27),
        cardStrongBg = Color(0xEB143A31),
        wellBg = Color(0xCC091E19),
        cardBorder = Color(0x33FBBF24),
        textPrimary = Color(0xFFF8FAFC),
        textSecondary = Color(0xFFCBD5E1),
        textMuted = Color(0xFF86A89E),
        accent = Color(0xFFFBBF24),
        accentStrong = Color(0xFFD97706),
        accentPillBg = Color(0x2EFBBF24),
        accentBorder = Color(0x80FBBF24),
        navBg = Color(0xD90A1F1A),
        todayDot = Color(0xFFFBBF24)
    )
}

val LocalFormaPalette = staticCompositionLocalOf { paletteFor(AppThemeId.NEWYEAR) }

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    strong: Boolean = false,
    activeBorder: Boolean = false,
    showSnowCap: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val p = LocalFormaPalette.current
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .clip(shape)
            .background(if (strong) p.cardStrongBg else p.cardBg)
            .border(
                width = if (activeBorder) 1.5.dp else 1.dp,
                color = if (activeBorder) p.accentBorder else p.cardBorder,
                shape = shape
            )
    ) {
        content()
        if (showSnowCap && p.id == AppThemeId.NEWYEAR) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
            ) {
                val w = size.width
                val path = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w, 0f)
                    lineTo(w, size.height * 0.65f)
                    cubicTo(w * 0.85f, size.height, w * 0.72f, size.height * 0.25f, w * 0.56f, size.height * 0.55f)
                    cubicTo(w * 0.40f, size.height * 0.85f, w * 0.24f, size.height * 0.22f, 0f, size.height * 0.60f)
                    close()
                }
                drawPath(
                    path = path,
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.82f), Color(0xFFE0F2FE).copy(alpha = 0.12f))
                    )
                )
            }
        }
    }
}

@Composable
fun NewYearGarlandBar(modifier: Modifier = Modifier) {
    val p = LocalFormaPalette.current
    if (p.id != AppThemeId.NEWYEAR) return

    val infinite = rememberInfiniteTransition(label = "garland")
    val pulse by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bulbPulse"
    )
    val colors = listOf(Color(0xFFFDE047), Color(0xFFFB7185), Color(0xFF38BDF8), Color(0xFF34D399))

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(14.dp)
    ) {
        val w = size.width
        val path = Path().apply {
            moveTo(4f, 4f)
            val segments = 6
            val step = (w - 8f) / segments
            for (i in 0 until segments) {
                val x1 = 4f + i * step + step * 0.5f
                val x2 = 4f + (i + 1) * step
                quadraticBezierTo(x1, size.height * 0.95f, x2, 4f)
            }
        }
        drawPath(path, color = Color(0x52A7F3D0), style = Stroke(width = 2.2f, cap = StrokeCap.Round))

        val bulbs = 12
        for (i in 0 until bulbs) {
            val frac = (i + 0.5f) / bulbs
            val cx = 6f + frac * (w - 12f)
            val cy = size.height * 0.52f + sin(frac * PI * 6).toFloat() * 2.5f
            val alpha = if (i % 2 == 0) 0.45f + pulse * 0.55f else 1f - pulse * 0.55f
            val c = colors[i % colors.size]
            drawCircle(color = c.copy(alpha = alpha * 0.30f), radius = 9.5f, center = Offset(cx, cy))
            drawCircle(color = c.copy(alpha = alpha), radius = 4.2f, center = Offset(cx, cy))
        }
    }
}

private data class SnowFlake(var x: Float, var y: Float, val r: Float, val vy: Float, var phase: Float, val alpha: Float)

@Composable
fun NewYearSnowOverlay(modifier: Modifier = Modifier) {
    val p = LocalFormaPalette.current
    if (p.id != AppThemeId.NEWYEAR) return

    val flakes = remember {
        List(32) {
            SnowFlake(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                r = 2.5f + Random.nextFloat() * 4f,
                vy = 0.00055f + Random.nextFloat() * 0.00095f,
                phase = Random.nextFloat() * 6.28f,
                alpha = 0.28f + Random.nextFloat() * 0.45f
            )
        }
    }
    var frameTick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos { ns ->
                for (f in flakes) {
                    f.phase += 0.02f
                    f.y += f.vy
                    f.x += sin(f.phase) * 0.00035f
                    if (f.y > 1.03f) { f.y = -0.02f; f.x = Random.nextFloat() }
                    if (f.x > 1.03f) f.x = -0.02f else if (f.x < -0.03f) f.x = 1.02f
                }
                frameTick = ns
            }
        }
    }
    Canvas(modifier = modifier.fillMaxSize()) {
        if (frameTick >= 0L) {
            for (f in flakes) {
                drawCircle(
                    color = Color.White.copy(alpha = f.alpha),
                    radius = f.r,
                    center = Offset(f.x * size.width, f.y * size.height)
                )
            }
        }
    }
}
