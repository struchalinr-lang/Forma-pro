-- Forma Pro: reversible clean-up of inactive/pending client connections.
-- Apply AFTER the initial Forma Client setup and v0.4 migrations, in the SAME Supabase project.
-- Safe: existing assignments, completed workout logs and trainer_states are never deleted.
-- The only write entrypoint is an owner-checked SECURITY DEFINER RPC.
BEGIN;

ALTER TABLE public.forma_client_links
  ADD COLUMN IF NOT EXISTS archived_at timestamptz;

CREATE INDEX IF NOT EXISTS forma_links_trainer_visible_idx
  ON public.forma_client_links(trainer_uid, status)
  WHERE archived_at IS NULL;

CREATE OR REPLACE FUNCTION public.forma_set_client_link_hidden(
  p_link_id uuid,
  p_hidden boolean
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_link public.forma_client_links%ROWTYPE;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Сначала войдите в аккаунт тренера';
  END IF;
  IF p_link_id IS NULL OR p_hidden IS NULL THEN
    RAISE EXCEPTION 'Неверный запрос';
  END IF;
  SELECT * INTO v_link FROM public.forma_client_links
    WHERE id = p_link_id AND trainer_uid = v_uid FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Подключение не найдено или нет доступа';
  END IF;
  IF p_hidden AND v_link.status = 'active' THEN
    RAISE EXCEPTION 'Сначала отключите активного клиента';
  END IF;
  IF p_hidden THEN
    -- Cancel unclaimed invitations. Never cascade-delete logs or assignments.
    UPDATE public.forma_client_links
    SET archived_at = now(),
        status = CASE WHEN status = 'pending' THEN 'revoked' ELSE status END,
        invite_hash = NULL,
        invite_expires_at = NULL
    WHERE id = p_link_id;
  ELSE
    -- Restoring a hidden row does not reactivate it or issue an invitation.
    UPDATE public.forma_client_links SET archived_at = NULL WHERE id = p_link_id;
  END IF;
  RETURN TRUE;
END;
$$;

REVOKE ALL ON FUNCTION public.forma_set_client_link_hidden(uuid,boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.forma_set_client_link_hidden(uuid,boolean) TO authenticated;

-- Legacy invite RPC reuses the same link row when trainer generates a new code.
-- Ensure a fresh invitation always reappears in the list even if this row was hidden.
CREATE OR REPLACE FUNCTION public.forma_unhide_on_new_invite()
RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
  IF NEW.status = 'pending' AND NEW.invite_hash IS NOT NULL THEN
    NEW.archived_at := NULL;
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS forma_links_unhide_new_invite ON public.forma_client_links;
CREATE TRIGGER forma_links_unhide_new_invite
BEFORE INSERT OR UPDATE OF status,invite_hash ON public.forma_client_links
FOR EACH ROW EXECUTE FUNCTION public.forma_unhide_on_new_invite();

COMMIT;
