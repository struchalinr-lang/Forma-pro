package com.fittrainer.live

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject

/**
 * Android is the source of truth for delivering rest timer notifications.
 * JS may remove an expired timer before AlarmManager has dispatched it;
 * reconcile() treats that as a completion, NOT as a manual cancellation.
 *
 * All entry points are delivered on the Android main thread (WebView bridge
 * posts to the UI thread; BroadcastReceiver runs on the main thread).
 */
internal object RestTimerScheduler {
    private const val TAG = "FormaRestTimer"
    private const val PREFS = "forma_rest_alarms_v2"
    private const val KEY_RECORDS = "records"
    private const val MAX_RECORDS = 300
    private const val COMPLETED_KEEP_MS = 48L * 60 * 60 * 1000
    private const val LATE_NOTIFICATION_LIMIT_MS = 30L * 60 * 1000
    private const val ACTION_TIMER = "com.fittrainer.live.REST_TIMER"

    data class Timer(
        val id: String,
        val endTimeMs: Long,
        val clientName: String,
        val exerciseName: String,
        val playSound: Boolean,
        val done: Boolean = false
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("end", endTimeMs)
            put("name", clientName)
            put("exercise", exerciseName)
            put("sound", playSound)
            put("done", done)
        }
    }

    private fun read(context: Context): MutableMap<String, Timer> {
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_RECORDS, "{}") ?: "{}"
        return try {
            val raw = JSONObject(json)
            val result = linkedMapOf<String, Timer>()
            val keys = raw.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val item = raw.optJSONObject(id) ?: continue
                val end = item.optLong("end", 0L)
                if (id.isNotBlank() && end > 0L) {
                    result[id] = Timer(
                        id, end, item.optString("name"), item.optString("exercise"),
                        item.optBoolean("sound", true), item.optBoolean("done", false)
                    )
                }
            }
            result
        } catch (error: Exception) {
            Log.e(TAG, "Could not read saved timers", error)
            linkedMapOf()
        }
    }

    private fun write(context: Context, data: Map<String, Timer>) {
        val json = JSONObject()
        data.forEach { (id, timer) -> json.put(id, timer.toJson()) }
        // Commit is deliberate: a notification may fire before the next JS tick,
        // and the state must survive a process kill / immediate reboot.
        if (!context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_RECORDS, json.toString()).commit()) {
            Log.e(TAG, "Could not persist timer schedule")
        }
    }

    private fun pendingIntent(context: Context, id: String, create: Boolean = true): PendingIntent? {
        val intent = Intent(context, RestTimerReceiver::class.java).apply {
            action = ACTION_TIMER
            data = Uri.parse("forma-rest://timer/${Uri.encode(id)}")
            putExtra(RestTimerReceiver.EXTRA_TIMER_ID, id)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or
            (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        // URI distinguishes timers; requestCode is kept for compatibility with older releases.
        return PendingIntent.getBroadcast(context, 4202, intent, flags)
    }

    private fun cancel(context: Context, id: String) {
        try {
            val pi = pendingIntent(context, id, create = false) ?: return
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
            pi.cancel()
        } catch (error: Exception) {
            Log.e(TAG, "Failed to cancel rest alarm", error)
        }
    }

    private fun schedule(context: Context, timer: Timer): Boolean {
        return try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pendingIntent(context, timer.id) ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timer.endTimeMs, pi)
                Log.w(TAG, "Exact alarms unavailable; scheduled inexact fallback")
            } else {
                try {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timer.endTimeMs, pi)
                } catch (error: SecurityException) {
                    Log.w(TAG, "Exact alarm denied; using inexact fallback", error)
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timer.endTimeMs, pi)
                }
            }
            true
        } catch (error: Exception) {
            Log.e(TAG, "Failed to schedule timer ${timer.id}", error)
            false
        }
    }

    /** Called whenever JS publishes the *currently running* timers. */
    fun reconcile(context: Context, json: String, playSound: Boolean) {
        val supplied = try { JSONArray(json) } catch (error: Exception) {
            Log.e(TAG, "Invalid timer list from WebView; leaving existing alarms untouched", error)
            return
        }
        val now = System.currentTimeMillis()
        val stored = read(context)
        val wanted = linkedMapOf<String, Timer>()
        for (i in 0 until minOf(supplied.length(), MAX_RECORDS)) {
            val entry = supplied.optJSONObject(i) ?: continue
            val id = entry.optString("id").take(100)
            val end = entry.optLong("endTimeMs")
            if (id.isBlank() || end <= now) continue
            wanted[id] = Timer(
                id, end,
                entry.optString("clientName").take(120),
                entry.optString("exerciseName").take(180),
                playSound
            )
        }
        val due = mutableListOf<Timer>()
        // A timer absent from JS is either manually stopped (deadline in future)
        // or has naturally reached zero. Never cancel the latter before notifying.
        for ((id, old) in stored.toMap()) {
            if (old.done) continue
            if (id !in wanted) {
                cancel(context, id)
                stored[id] = old.copy(done = true)
                if (old.endTimeMs <= now && now - old.endTimeMs <= LATE_NOTIFICATION_LIMIT_MS) {
                    due += old
                }
            }
        }
        for ((id, fresh) in wanted) {
            val old = stored[id]
            if (old != null && !old.done && old.endTimeMs == fresh.endTimeMs &&
                old.playSound == fresh.playSound && old.clientName == fresh.clientName &&
                old.exerciseName == fresh.exerciseName) continue
            val scheduled = schedule(context, fresh)
            if (scheduled) stored[id] = fresh
            // If scheduling fails, keep the old pending record (if any), rather
            // than silently replacing it with a record that has no OS alarm.
        }
        // Remove obsolete delivery markers, keep recent ones for deduplication.
        stored.entries.removeAll { (_, timer) ->
            timer.done && now - timer.endTimeMs > COMPLETED_KEEP_MS
        }
        write(context, stored)
        due.forEach { RestTimerReceiver.showTimerNotification(context, it) }
        clearLegacyAlarms(context, wanted.keys)
    }

    /** System alarm fired. Guard against stale/cancelled PendingIntents and duplicates. */
    fun onAlarmFired(context: Context, id: String): Boolean {
        val stored = read(context)
        val timer = stored[id] ?: return false
        if (timer.done) return true
        val now = System.currentTimeMillis()
        if (now < timer.endTimeMs) {
            schedule(context, timer)
            return true
        }
        stored[id] = timer.copy(done = true)
        write(context, stored)
        RestTimerReceiver.showTimerNotification(context, timer)
        return true
    }

    /** Used only by the backward-compatible single-timer bridge. */
    fun cancelLegacy(context: Context) {
        val stored = read(context)
        val old = stored["legacy_rest_timer"] ?: return
        if (!old.done) {
            cancel(context, old.id)
            stored[old.id] = old.copy(done = true)
            write(context, stored)
        }
    }

    /** BOOT_COMPLETED, package update or exact-alarm permission grant. */
    fun restorePending(context: Context, fromBoot: Boolean = false) {
        val now = System.currentTimeMillis()
        val stored = read(context)
        var changed = false
        for ((id, timer) in stored.toMap()) {
            if (timer.done) continue
            if (timer.endTimeMs <= now) {
                // After a device reboot, never ring for a long-expired rest period.
                stored[id] = timer.copy(done = true)
                changed = true
            } else {
                schedule(context, timer)
            }
        }
        if (changed) write(context, stored)
        Log.i(TAG, "Restored pending timers (boot=$fromBoot)")
    }

    private fun clearLegacyAlarms(context: Context, current: Set<String>) {
        // The previous app release stored only IDs in this separate preference.
        // Reconcile them on first launch to avoid orphaned old PendingIntents.
        val prefs = context.getSharedPreferences("rest_alarm_ids", Context.MODE_PRIVATE)
        val oldIds = prefs.getStringSet("ids", emptySet())?.toSet() ?: emptySet()
        for (id in oldIds) {
            if (id !in current) cancel(context, id)
        }
        if (oldIds.isNotEmpty()) prefs.edit().remove("ids").apply()
    }
}
