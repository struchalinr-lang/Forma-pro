package com.fittrainer.live

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.view.Gravity
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.io.FileOutputStream
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_OPEN_CLIENT_ID = "forma_open_client_id"
        private const val APP_ASSET_URL = "https://appassets.androidplatform.net/assets/index.html"
    }
    private var pageReady = false
    private var pendingOpenClientId: String? = null

    private lateinit var webView: WebView
    // Activity-level Back works for system gestures from either edge and
    // for three-button navigation. The WebView never needs edge-touch hooks.
    private val formaBackCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() = handleFormaSystemBack()
    }
    private var formaBackPending = false
    // An actual native cover protects the first WebView paint. HTML notifies us
    // only after initial rendering, fonts and ViewPager warm-up have finished.
    private var nativeSplashOverlay: View? = null
    private var splashDismissed = false
    private val splashHandler = Handler(Looper.getMainLooper())
    private val splashTimeout = Runnable {
        Log.w("FormaStartup", "HTML readiness was not received; releasing native splash as a fallback")
        dismissNativeSplash()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun createNativeSplash(themeHex: String, isDark: Boolean): View {
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(if (isDark) Color.parseColor(themeHex) else Color.WHITE)
            isClickable = true
            isFocusable = true
            contentDescription = "Загрузка Forma Pro"
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.forma_splash_mark)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        overlay.addView(logo, LinearLayout.LayoutParams(dp(76), dp(76)))
        val name = TextView(this).apply {
            text = "Forma Pro"
            textSize = 23f
            letterSpacing = -0.04f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setTextColor(if (isDark) Color.rgb(241, 245, 250) else Color.rgb(39, 48, 59))
            gravity = Gravity.CENTER
        }
        overlay.addView(name, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })
        return overlay
    }

    private fun dismissNativeSplash() {
        if (splashDismissed) return
        splashDismissed = true
        splashHandler.removeCallbacks(splashTimeout)
        val overlay = nativeSplashOverlay ?: return
        overlay.animate().cancel()
        overlay.animate()
            .alpha(0f)
            .setDuration(260L)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                (overlay.parent as? ViewGroup)?.removeView(overlay)
                if (nativeSplashOverlay === overlay) nativeSplashOverlay = null
            }
            .start()
    }
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val bgTimerHandler = Handler(Looper.getMainLooper())
    private var bgTimerRunnable: Runnable? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var toneGenerator: ToneGenerator? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            filePathCallback?.onReceiveValue(arrayOf(uri))
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        pendingOpenClientId = intent?.getStringExtra(EXTRA_OPEN_CLIENT_ID)
        // Pick the matching native window *before* drawing the WebView.
        val launchPrefs = getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
        val savedBackup = launchPrefs.getString("workout_state_backup", "") ?: ""
        val backupIsDark = listOf("night", "obsidian", "newyear", "deadpool")
            .any { savedBackup.contains("\"theme\":\"$it\"") }
        val launchIsDark = launchPrefs.getBoolean("launch_is_dark", backupIsDark)
        if (launchIsDark) setTheme(R.style.AppThemeDark)
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, formaBackCallback)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                setTaskDescription(ActivityManager.TaskDescription.Builder().setLabel("Forma Pro").build())
            } else {
                @Suppress("DEPRECATION")
                setTaskDescription(ActivityManager.TaskDescription("Forma Pro"))
            }
        } catch (_: Exception) {}

        // The old file:// origin and the new HTTPS origin have different localStorage.
        // Preserve the previous native snapshot for recovery, but never silently import
        // that potentially stale database into the new origin. User imports a verified JSON.
        val originPrefs = getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
        if (!originPrefs.getBoolean("forma_https_origin_seen_v1", false)) {
            val oldBackup = originPrefs.getString("workout_state_backup", "") ?: ""
            originPrefs.edit()
                .putString("forma_legacy_file_origin_backup", oldBackup)
                .putBoolean("forma_https_origin_seen_v1", true)
                .commit()
        }
        // Read saved theme from native backup immediately so launch has zero color flash or artifacts
        val prefs = getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
        val savedJson = prefs.getString("workout_state_backup", "") ?: ""
        val isObsidian = savedJson.contains("\"theme\":\"obsidian\"")
        val isNight = savedJson.contains("\"theme\":\"night\"")
        val isSage = savedJson.contains("\"theme\":\"sage\"")
        val isNewYear = savedJson.contains("\"theme\":\"newyear\"")
        val isDeadpool = savedJson.contains("\"theme\":\"deadpool\"")

        val defaultHex = when {
            isDeadpool -> "#0C0C10"
            isObsidian -> "#0C0D12"
            isNight -> "#0C131D"
            isNewYear -> "#0A221D"
            isSage -> "#EDF3F0"
            else -> "#EEF1F6"
        }
        // The compact preference is updated by the HTML bridge on every theme
        // change. It is fresher than the full state backup, which is asynchronous.
        val storedHex = prefs.getString("launch_theme_color", defaultHex) ?: defaultHex
        val initialHex = try { Color.parseColor(storedHex); storedHex }
            catch (_: IllegalArgumentException) { defaultHex }
        val initialDark = launchIsDark

        // Prepare high-priority timer notification channel & request Android 13+ permission once
        RestTimerReceiver.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
            }
        }
        val parsedInitColor = Color.parseColor(initialHex)

        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.statusBarColor = parsedInitColor
        window.navigationBarColor = parsedInitColor

        // Request maximum native display refresh rate (120Hz / 90Hz) for ultra-smooth gestures
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    this.display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val bestMode = display?.supportedModes?.maxByOrNull { it.refreshRate }
                if (bestMode != null) {
                    val params = window.attributes
                    params.preferredDisplayModeId = bestMode.modeId
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        params.preferredRefreshRate = bestMode.refreshRate
                    }
                    window.attributes = params
                }
            }
        } catch (_: Exception) {}
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.isAppearanceLightStatusBars = !initialDark
            it.isAppearanceLightNavigationBars = !initialDark
        }

        webView = WebView(this)
        webView.setBackgroundColor(parsedInitColor)
        webView.setLayerType(View.LAYER_TYPE_NONE, null)
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        val root = FrameLayout(this)
        root.addView(webView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        val startupCover = createNativeSplash(initialHex, initialDark)
        nativeSplashOverlay = startupCover
        root.addView(startupCover, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
        // HTML has its own 3.2s watchdog. This separate safeguard prevents a
        // permanently blocked activity if an unexpected JavaScript error occurs.
        splashHandler.postDelayed(splashTimeout, 9000L)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        // Supabase must honor server Cache-Control headers, not stale offline cache.
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        // file:// pages have restricted network origin and break Supabase fetch in WebView.
        // Serve only packaged APK assets from a private HTTPS origin, with no file access.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?, request: WebResourceRequest?
            ): WebResourceResponse? = request?.url?.let { assetLoader.shouldInterceptRequest(it) }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                // Keep external pages out of the privileged AndroidBridge WebView.
                val uri = request?.url ?: return true
                return uri.scheme != "https" ||
                    uri.host != "appassets.androidplatform.net" ||
                    uri.path != "/assets/index.html"
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url != APP_ASSET_URL) return
                pageReady = true
                view?.evaluateJavascript(
                    "if (typeof applyTheme === 'function' && typeof appState !== 'undefined') applyTheme(appState.theme);",
                    null
                )
                openPendingNotificationClient()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                fileChooserLauncher.launch("*/*")
                return true
            }
        }

        webView.loadUrl(APP_ASSET_URL)
    }

    private fun handleFormaSystemBack() {
        if (formaBackPending) return
        if (!::webView.isInitialized) {
            fallbackFormaBack()
            return
        }
        formaBackPending = true
        // evaluateJavascript executes on the UI thread. Each invocation
        // performs exactly ONE navigation step inside the app.
        webView.evaluateJavascript(
            "(function(){try{return !!(window.formaHandleBackNavigation && window.formaHandleBackNavigation());}catch(e){console.warn('Forma Back',e);return false;}})();"
        ) { handled ->
            formaBackPending = false
            if (handled != "true") fallbackFormaBack()
        }
    }

    private fun fallbackFormaBack() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
            return
        }
        // Delegate to Android's normal back action instead of recursively
        // re-entering our callback, preserving the original home behavior.
        formaBackCallback.isEnabled = false
        try { onBackPressedDispatcher.onBackPressed() }
        finally { formaBackCallback.isEnabled = true }
    }

    override fun onResume() {
        super.onResume()
        // A grant from Android Settings is not delivered by an ordinary permissions
        // callback. Re-register outstanding timers only when exact access changes
        // from denied to granted (not on EVERY resume, which could shift alarms).
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            val prefs = getSharedPreferences("forma_alarm_access", Context.MODE_PRIVATE)
            val previous = prefs.getBoolean("was_exact_allowed", false)
            prefs.edit().putBoolean("was_exact_allowed", exact).apply()
            if (exact && !previous) RestTimerScheduler.restorePending(this)
        } catch (error: Exception) {
            Log.w("FormaRestTimer", "Could not check exact-alarm access", error)
        }
        // Do NOT dismiss other clients' notifications when returning to the app.
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(EXTRA_OPEN_CLIENT_ID)?.let {
            pendingOpenClientId = it
            openPendingNotificationClient()
        }
    }

    private fun openPendingNotificationClient() {
        if (!pageReady || !::webView.isInitialized) return
        val id = pendingOpenClientId ?: return
        pendingOpenClientId = null
        val safeId = org.json.JSONObject.quote(id)
        webView.evaluateJavascript(
            "if (typeof window.openClientFromAndroidNotification === 'function') " +
                "{ window.openClientFromAndroidNotification($safeId); true; } else { false; }"
        ) { result ->
            if (result == "false") {
                pendingOpenClientId = id
                Log.w("FormaRestTimer", "Client navigation not ready; retaining notification target")
            }
        }
    }

    override fun onDestroy() {
        splashHandler.removeCallbacksAndMessages(null)
        nativeSplashOverlay?.animate()?.cancel()
        nativeSplashOverlay = null
        bgTimerHandler.removeCallbacksAndMessages(null)
        bgTimerRunnable = null
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        wakeLock = null

        try {
            toneGenerator?.release()
        } catch (_: Exception) {}
        toneGenerator = null

        try {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.stopLoading()
            webView.destroy()
        } catch (_: Exception) {}

        super.onDestroy()
    }

    inner class AndroidBridge(private val context: Context) {
        /** Read-only status for the Settings diagnostics card. No permission is
         * silently requested; the trainer must tap a button to open Settings. */
        @JavascriptInterface
        fun getTimerDeliveryStatus(): String {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            val permitted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            val channel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                nm.getNotificationChannel(RestTimerReceiver.CHANNEL_ID) else null
            return JSONObject().apply {
                put("exact", exact)
                put("notifications", permitted && nm.areNotificationsEnabled())
                put("channelEnabled", channel == null || channel.importance != NotificationManager.IMPORTANCE_NONE)
                put("channelSound", channel == null || channel.sound != null)
                put("sdk", Build.VERSION.SDK_INT)
            }.toString()
        }

        @JavascriptInterface
        fun openExactAlarmAccessSettings() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return@runOnUiThread
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                        data = Uri.parse("package:$packageName")
                    })
                } catch (error: Exception) {
                    Log.w("FormaRestTimer", "Exact-alarm settings unavailable", error)
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName")))
                    } catch (_: Exception) {}
                }
            }
        }

        @JavascriptInterface
        fun requestTimerNotificationAccess() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity,
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1002)
                } else {
                    try {
                        startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        })
                    } catch (_: Exception) {}
                }
            }
        }
        // Called once at the end of FormaStartup.finish(), after the HTML
        // interface has painted and its compositor has been prepared.
        @JavascriptInterface
        fun hideNativeSplash() {
            runOnUiThread { dismissNativeSplash() }
        }

        @JavascriptInterface
        fun saveBackup(jsonState: String) {
            context.getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
                .edit()
                .putString("workout_state_backup", jsonState)
                .putBoolean("forma_https_origin_has_saved_state", true)
                .apply()
        }

        @JavascriptInterface
        fun loadBackup(): String {
            val prefs = context.getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
            // Old native data is still preserved under forma_legacy_file_origin_backup,
            // but only explicit JSON import should restore the authoritative dataset.
            if (!prefs.getBoolean("forma_https_origin_has_saved_state", false)) return ""
            return prefs.getString("workout_state_backup", "") ?: ""
        }

        @JavascriptInterface
        fun setStatusBarTheme(isNight: Boolean, hexColor: String) {
            // Keep the launch-window color available before the next WebView boot.
            context.getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
                .edit().putBoolean("launch_is_dark", isNight)
                .putString("launch_theme_color", hexColor).apply()
            runOnUiThread {
                try {
                    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                    val parsedColor = Color.parseColor(hexColor)
                    window.statusBarColor = parsedColor
                    window.navigationBarColor = parsedColor
                    webView.setBackgroundColor(parsedColor)
                    // Keep the native cover in sync if the HTML restored a
                    // different theme from its own localStorage on cold start.
                    nativeSplashOverlay?.setBackgroundColor(if (isNight) parsedColor else Color.WHITE)
                    val controller = WindowInsetsControllerCompat(window, window.decorView)
                    controller.isAppearanceLightStatusBars = !isNight
                    controller.isAppearanceLightNavigationBars = !isNight
                } catch (_: Exception) {}
            }
        }

        // OS alarms are persisted and deduplicated by RestTimerScheduler.
        @JavascriptInterface
        fun syncBackgroundTimers(timersJson: String, playSound: Boolean) {
            runOnUiThread {
                RestTimerScheduler.reconcile(context, timersJson, playSound)
                cancelAlarmInternal() // cancel pre-v2 single timer if present
            }
        }

        // Backward-compatible bridge for older HTML versions (current UI uses
        // syncBackgroundTimers and independent per-client timers instead).
        @JavascriptInterface
        fun scheduleBackgroundTimer(seconds: Int, playSound: Boolean) {
            scheduleBackgroundTimerWithInfo(seconds, playSound, "", "")
        }

        @JavascriptInterface
        fun scheduleBackgroundTimerWithInfo(seconds: Int, playSound: Boolean, clientName: String, exName: String) {
            val payload = org.json.JSONArray().put(org.json.JSONObject().apply {
                put("id", "legacy_rest_timer")
                put("endTimeMs", System.currentTimeMillis() + maxOf(1, seconds) * 1000L)
                put("clientName", clientName)
                put("exerciseName", exName)
            }).toString()
            runOnUiThread { RestTimerScheduler.reconcile(context, payload, playSound) }
        }

        @JavascriptInterface
        fun cancelBackgroundTimer() {
            runOnUiThread {
                cancelAlarmInternal()
                RestTimerScheduler.cancelLegacy(context)
                bgTimerRunnable?.let { bgTimerHandler.removeCallbacks(it) }
                bgTimerRunnable = null
                try {
                    if (wakeLock?.isHeld == true) wakeLock?.release()
                } catch (_: Exception) {}
            }
        }

        private fun cancelAlarmInternal() {
            try {
                val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(context, RestTimerReceiver::class.java)
                val pi = PendingIntent.getBroadcast(
                    context,
                    4201,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                am.cancel(pi)
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun playAlarmSound() {
            Thread {
                try {
                    val sampleRate = 44100
                    val durationSec = 1.15
                    val numSamples = (sampleRate * durationSec).toInt()
                    val pcm = ShortArray(numSamples)
                    // Warm Apple-style studio chime: C5 (523.25), E5 (659.25), G5 (783.99), B5 (987.77)
                    val notes = doubleArrayOf(523.25, 659.25, 783.99, 987.77)
                    val starts = doubleArrayOf(0.0, 0.11, 0.22, 0.34)
                    for (i in 0 until numSamples) {
                        val t = i.toDouble() / sampleRate
                        var sample = 0.0
                        for (nIdx in notes.indices) {
                            val dt = t - starts[nIdx]
                            if (dt >= 0.0) {
                                val f = notes[nIdx]
                                val env = Math.min(1.0, dt / 0.014) * Math.exp(-dt * 4.6)
                                val tone = Math.sin(2.0 * Math.PI * f * dt) * 0.72 +
                                           Math.sin(2.0 * Math.PI * f * 2.0 * dt) * 0.20 * Math.exp(-dt * 7.5) +
                                           Math.sin(2.0 * Math.PI * f * 3.0 * dt) * 0.08 * Math.exp(-dt * 11.0)
                                sample += tone * env * 0.34
                            }
                        }
                        val clamped = Math.max(-1.0, Math.min(1.0, sample))
                        pcm[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
                    }

                    val track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(pcm.size * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build()

                    track.write(pcm, 0, pcm.size)
                    track.play()
                    Thread.sleep(1250)
                    track.release()
                } catch (_: Exception) {}
            }.start()
        }

        @JavascriptInterface
        fun downloadBase64Xlsx(base64Data: String, fileName: String): Boolean {
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val mime = if (fileName.endsWith(".json", ignoreCase = true)) {
                        "application/json"
                    } else {
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    }
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("MediaStore insert failed")
                    resolver.openOutputStream(uri)?.use { it.write(bytes) }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } else {
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val outFile = File(downloadsDir, fileName)
                    FileOutputStream(outFile).use { it.write(bytes) }
                }
                Toast.makeText(context, "Сохранено в Загрузки: $fileName", Toast.LENGTH_LONG).show()
                return true
            } catch (e: Exception) {
                Toast.makeText(context, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
                return false
            }
        }
    }
}
