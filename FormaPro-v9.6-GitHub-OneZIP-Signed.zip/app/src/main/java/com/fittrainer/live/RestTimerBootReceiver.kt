package com.fittrainer.live

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/** Only reschedules still-future rest timers; never starts a permanent service. */
class RestTimerBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            intent.action == "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED") {
            try {
                RestTimerScheduler.restorePending(context, intent.action == Intent.ACTION_BOOT_COMPLETED)
            } catch (error: Exception) {
                Log.e("FormaRestTimer", "Could not restore timers", error)
            }
        }
    }
}
