package com.fittrainer.live

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class RestTimerReceiver : BroadcastReceiver() {
    companion object {
        const val CHANNEL_ID = "forma_rest_timer_heads_up_v1" // preserve user channel preferences
        private const val SILENT_CHANNEL_ID = "forma_rest_timer_silent_v1"
        const val EXTRA_TIMER_ID = "extra_timer_id"
        // Only for alarms scheduled before upgrading from the previous release.
        private const val EXTRA_CLIENT_NAME = "extra_client_name"
        private const val EXTRA_EX_NAME = "extra_ex_name"
        private const val EXTRA_PLAY_SOUND = "extra_play_sound"

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                nm.createNotificationChannel(NotificationChannel(
                    CHANNEL_ID, "Таймер отдыха Forma Pro", NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Уведомления об окончании отдыха между подходами"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 260, 140, 260)
                    setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), attrs)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                })
            }
            if (nm.getNotificationChannel(SILENT_CHANNEL_ID) == null) {
                nm.createNotificationChannel(NotificationChannel(
                    SILENT_CHANNEL_ID, "Таймер отдыха без звука", NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Тихие уведомления таймера отдыха"
                    setSound(null, null)
                    enableVibration(false)
                })
            }
        }

        internal fun showTimerNotification(context: Context, timer: RestTimerScheduler.Timer) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                Log.w("FormaRestTimer", "Notification permission denied; timer ${timer.id} completed")
                return
            }
            try {
                ensureChannel(context)
                val openIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    data = Uri.parse("forma-client://open/${Uri.encode(timer.id)}")
                    putExtra(MainActivity.EXTRA_OPEN_CLIENT_ID, timer.id)
                }
                val pending = PendingIntent.getActivity(
                    context, timer.id.hashCode(), openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val title = if (timer.clientName.isNotBlank())
                    "Отдых окончен — ${timer.clientName}" else "Отдых окончен"
                val body = if (timer.exerciseName.isNotBlank())
                    "Пора к подходу • ${timer.exerciseName}" else "Пора переходить к следующему подходу"
                val channel = if (timer.playSound) CHANNEL_ID else SILENT_CHANNEL_ID
                val notification = NotificationCompat.Builder(context, channel)
                    .setSmallIcon(R.drawable.ic_timer_notification)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                    .setAutoCancel(true)
                    .setContentIntent(pending)
                    .setOnlyAlertOnce(true)
                    .build()
                (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .notify(timer.id.hashCode(), notification)
            } catch (error: Exception) {
                Log.e("FormaRestTimer", "Could not show rest notification", error)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(EXTRA_TIMER_ID).orEmpty()
        if (id.isNotBlank() && RestTimerScheduler.onAlarmFired(context, id)) return
        // An already-scheduled PendingIntent from the pre-v2 release may fire
        // after an in-place app update, before JS can re-register the timer.
        // Accept ONLY the old extras; new alarms always use persisted records.
        if (intent.hasExtra(EXTRA_CLIENT_NAME) || intent.hasExtra(EXTRA_EX_NAME)) {
            showTimerNotification(context, RestTimerScheduler.Timer(
                if (id.isNotBlank()) id else "legacy_rest_timer",
                System.currentTimeMillis(),
                intent.getStringExtra(EXTRA_CLIENT_NAME).orEmpty(),
                intent.getStringExtra(EXTRA_EX_NAME).orEmpty(),
                intent.getBooleanExtra(EXTRA_PLAY_SOUND, true),
                done = true
            ))
        }
    }
}
