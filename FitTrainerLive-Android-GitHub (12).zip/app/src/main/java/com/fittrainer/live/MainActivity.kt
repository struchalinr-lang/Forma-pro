package com.fittrainer.live

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.app.UiModeManager
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.TypefaceSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.roundToInt
import java.io.File
import java.io.FileOutputStream
import org.json.JSONArray

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingTimerClientId: String? = null
    private var webViewReady: Boolean = false
    private var lastInsetTopCss: Int = 0
    private var lastInsetBottomCss: Int = 0
    private var nativeSplashOverlay: View? = null
    private var nativeSplashHidden: Boolean = false
    private val splashWatchdogHandler = Handler(Looper.getMainLooper())
    private val splashWatchdogRunnable = Runnable { hideNativeSplashInternal() }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            filePathCallback?.onReceiveValue(arrayOf(uri))
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingTimerClientId = intent?.getStringExtra(RestTimerReceiver.EXTRA_TIMER_ID)?.takeIf { it.isNotBlank() }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                setTaskDescription(ActivityManager.TaskDescription.Builder().setLabel("Forma Pro").build())
            } else {
                @Suppress("DEPRECATION")
                setTaskDescription(ActivityManager.TaskDescription("Forma Pro"))
            }
        } catch (_: Exception) {}

        // Read saved theme immediately so launch opens straight into Forma Pro splash (white or dark) with zero bluish flash
        val prefs = getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
        val savedJson = prefs.getString("workout_state_backup", "") ?: ""
        val hasDirectPref = prefs.contains("saved_is_dark")
        val savedIsDarkPref = prefs.getBoolean("saved_is_dark", false)
        val savedHexPref = (prefs.getString("saved_theme_hex", "") ?: "").uppercase()

        val isDeadpool = if (hasDirectPref) savedHexPref == "#0C0C10" else savedJson.contains("\"theme\":\"deadpool\"")
        val isObsidian = if (hasDirectPref) savedHexPref == "#0C0D12" else savedJson.contains("\"theme\":\"obsidian\"")
        val isNight = if (hasDirectPref) savedHexPref == "#0C131D" else savedJson.contains("\"theme\":\"night\"")
        val isNewYear = if (hasDirectPref) savedHexPref == "#0A221D" else savedJson.contains("\"theme\":\"newyear\"")
        val initialDark = if (hasDirectPref) savedIsDarkPref else (isDeadpool || isObsidian || isNight || isNewYear)

        val splashBgHex = when {
            isDeadpool -> "#0C0C10"
            isObsidian -> "#0C0D12"
            isNight -> "#0C131D"
            isNewYear -> "#0A221D"
            initialDark -> "#0C131D"
            else -> "#FFFFFF"
        }
        val splashTextHex = when {
            isDeadpool -> "#F6F3F4"
            isObsidian -> "#F1F3F7"
            isNewYear -> "#F1F9F5"
            initialDark -> "#F1F5FA"
            else -> "#27303B"
        }
        val initialHex = splashBgHex

        // Prepare high-priority timer notification channel & request Android 13+ permission once
        RestTimerReceiver.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
            }
        }
        val parsedInitColor = Color.parseColor(initialHex)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }

        // Request maximum native display refresh rate (120Hz / 90Hz) for ultra-smooth gestures
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    this.display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val bestMode = display?.supportedModes?.maxByOrNull { it.refreshRate }
                if (bestMode != null) {
                    val params = window.attributes
                    params.preferredDisplayModeId = bestMode.modeId
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        params.preferredRefreshRate = bestMode.refreshRate
                    }
                    window.attributes = params
                }
            }
        } catch (_: Exception) {}
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.isAppearanceLightStatusBars = !initialDark
            it.isAppearanceLightNavigationBars = !initialDark
        }

        window.decorView.setBackgroundColor(parsedInitColor)
        val rootContainer = FrameLayout(this).apply {
            setBackgroundColor(parsedInitColor)
        }

        webView = WebView(this)
        webView.setBackgroundColor(parsedInitColor)
        webView.setLayerType(View.LAYER_TYPE_NONE, null)
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        rootContainer.addView(
            webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val density = resources.displayMetrics.density
        val logoSizePx = (76f * density).roundToInt()
        val nameMarginTopPx = (16f * density).roundToInt()
        val parsedTextColor = Color.parseColor(splashTextHex)

        val splashOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(parsedInitColor)
            isClickable = true
            isFocusable = true
        }
        val logoView = ImageView(this).apply {
            setImageResource(R.drawable.ic_forma_splash_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Forma Pro"
        }
        splashOverlay.addView(logoView, LinearLayout.LayoutParams(logoSizePx, logoSizePx))

        val titleSpan = SpannableString("Forma Pro").apply {
            setSpan(TypefaceSpan("sans-serif-medium"), 0, 5, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            setSpan(TypefaceSpan("sans-serif-light"), 6, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val titleView = TextView(this).apply {
            text = titleSpan
            setTextColor(parsedTextColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 23f)
            letterSpacing = -0.045f
            gravity = Gravity.CENTER
        }
        val titleLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = nameMarginTopPx
        }
        splashOverlay.addView(titleView, titleLp)

        nativeSplashOverlay = splashOverlay
        rootContainer.addView(
            splashOverlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(rootContainer)
        splashWatchdogHandler.postDelayed(splashWatchdogRunnable, 3500L)

        ViewCompat.setOnApplyWindowInsetsListener(webView) { v, insets ->
            val sysBars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val density = resources.displayMetrics.density.coerceAtLeast(1f)
            lastInsetTopCss = (sysBars.top / density).roundToInt()
            lastInsetBottomCss = (sysBars.bottom / density).roundToInt()
            applySafeAreaInsetsToWebView()
            insets
        }
        ViewCompat.requestApplyInsets(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK

        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return uri.scheme != "file" || !uri.host.isNullOrEmpty() || uri.path != "/android_asset/index.html"
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url != "file:///android_asset/index.html") return
                webViewReady = true
                view?.evaluateJavascript(
                    "if (typeof applyTheme === 'function' && typeof appState !== 'undefined') applyTheme(appState.theme);",
                    null
                )
                applySafeAreaInsetsToWebView()
                dispatchPendingTimerClient()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                fileChooserLauncher.launch("*/*")
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!webViewReady) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    return
                }
                webView.evaluateJavascript(
                    "(function(){try{return typeof window.formaHandleBackNavigation==='function'&&window.formaHandleBackNavigation()?'1':'0';}catch(e){return '0';}})()"
                ) { result ->
                    val handled = result == "\"1\"" || result == "1" || result == "true"
                    if (!handled) {
                        if (webView.canGoBack()) {
                            webView.goBack()
                        } else {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        }
                    }
                }
            }
        })

        webView.loadUrl("file:///android_asset/index.html")
    }



    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val cId = intent.getStringExtra(RestTimerReceiver.EXTRA_TIMER_ID)?.takeIf { it.isNotBlank() }
        if (cId != null) {
            pendingTimerClientId = cId
            dispatchPendingTimerClient()
        }
    }

    private fun applySafeAreaInsetsToWebView() {
        if (!webViewReady) return
        val js = "document.documentElement.style.setProperty('--sat','${lastInsetTopCss}px');document.documentElement.style.setProperty('--sab','${lastInsetBottomCss}px');"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    private fun dispatchPendingTimerClient() {
        val cId = pendingTimerClientId ?: return
        if (!webViewReady) return
        pendingTimerClientId = null
        val escaped = org.json.JSONObject.quote(cId)
        webView.post {
            webView.evaluateJavascript(
                "if (typeof window.openClientFromAndroidNotification === 'function') window.openClientFromAndroidNotification($escaped);",
                null
            )
        }
    }

    override fun onResume() {
        super.onResume()
        RestTimerReceiver.cancelNotification(this)
    }

    private fun hideNativeSplashInternal() {
        if (nativeSplashHidden) return
        nativeSplashHidden = true
        splashWatchdogHandler.removeCallbacks(splashWatchdogRunnable)
        val overlay = nativeSplashOverlay ?: return
        nativeSplashOverlay = null
        overlay.animate()
            .alpha(0f)
            .setDuration(270L)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .withEndAction {
                try {
                    (overlay.parent as? ViewGroup)?.removeView(overlay)
                } catch (_: Exception) {}
            }
            .start()
    }

    override fun onDestroy() {
        splashWatchdogHandler.removeCallbacks(splashWatchdogRunnable)
        webViewReady = false
        try {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.stopLoading()
            webView.destroy()
        } catch (_: Exception) {}

        super.onDestroy()
    }

    inner class AndroidBridge(private val context: Context) {
        @JavascriptInterface
        fun saveBackup(jsonState: String) {
            context.getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
                .edit()
                .putString("workout_state_backup", jsonState)
                .apply()
        }

        @JavascriptInterface
        fun loadBackup(): String {
            return context.getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
                .getString("workout_state_backup", "") ?: ""
        }

        @JavascriptInterface
        fun hideNativeSplash() {
            runOnUiThread {
                hideNativeSplashInternal()
            }
        }

        @JavascriptInterface
        fun setStatusBarTheme(isNight: Boolean, hexColor: String) {
            context.getSharedPreferences("fittrainer_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean("saved_is_dark", isNight)
                .putString("saved_theme_hex", hexColor)
                .apply()
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val uiModeManager = context.getSystemService(UiModeManager::class.java)
                        val desiredMode = if (isNight) UiModeManager.MODE_NIGHT_YES else UiModeManager.MODE_NIGHT_NO
                        if (uiModeManager != null && uiModeManager.nightMode != desiredMode) {
                            uiModeManager.setApplicationNightMode(desiredMode)
                        }
                    }
                } catch (_: Exception) {}
                try {
                    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
                    val parsedColor = Color.parseColor(hexColor)
                    window.statusBarColor = Color.TRANSPARENT
                    window.navigationBarColor = Color.TRANSPARENT
                    webView.setBackgroundColor(parsedColor)
                    val controller = WindowInsetsControllerCompat(window, window.decorView)
                    controller.isAppearanceLightStatusBars = !isNight
                    controller.isAppearanceLightNavigationBars = !isNight
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun syncBackgroundTimers(timersJson: String, playSound: Boolean) {
            runOnUiThread {
                try {
                    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val prefs = context.getSharedPreferences("rest_alarm_ids", Context.MODE_PRIVATE)
                    val previous = prefs.getStringSet("ids", emptySet())?.toSet() ?: emptySet()
                    val array = JSONArray(timersJson)
                    val current = mutableSetOf<String>()
                    for (i in 0 until array.length()) {
                        val item = array.optJSONObject(i) ?: continue
                        val id = item.optString("id").take(100)
                        val end = item.optLong("endTimeMs")
                        if (id.isBlank() || end <= System.currentTimeMillis()) continue
                        current.add(id)
                        val intent = Intent(context, RestTimerReceiver::class.java).apply {
                            action = "com.fittrainer.live.REST_TIMER"
                            data = Uri.parse("forma-rest://timer/${Uri.encode(id)}")
                            putExtra(RestTimerReceiver.EXTRA_CLIENT_NAME, item.optString("clientName"))
                            putExtra(RestTimerReceiver.EXTRA_EX_NAME, item.optString("exerciseName"))
                            putExtra(RestTimerReceiver.EXTRA_PLAY_SOUND, playSound)
                            putExtra(RestTimerReceiver.EXTRA_TIMER_ID, id)
                        }
                        val pi = PendingIntent.getBroadcast(
                            context, 4202, intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
                            } else {
                                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
                            }
                        } catch (_: SecurityException) {
                            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
                        }
                    }
                    (previous - current).forEach { id ->
                        val intent = Intent(context, RestTimerReceiver::class.java).apply {
                            action = "com.fittrainer.live.REST_TIMER"
                            data = Uri.parse("forma-rest://timer/${Uri.encode(id)}")
                        }
                        val pi = PendingIntent.getBroadcast(
                            context, 4202, intent,
                            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                        )
                        if (pi != null) { am.cancel(pi); pi.cancel() }
                    }
                    prefs.edit().putStringSet("ids", current).apply()
                    cancelAlarmInternal()
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun scheduleBackgroundTimer(seconds: Int, playSound: Boolean) {
            scheduleBackgroundTimerWithInfo(seconds, playSound, "", "")
        }

        @JavascriptInterface
        fun scheduleBackgroundTimerWithInfo(seconds: Int, playSound: Boolean, clientName: String, exName: String) {
            runOnUiThread {
                val safeSec = if (seconds < 1) 1 else seconds
                cancelAlarmInternal()
                RestTimerReceiver.ensureChannel(context)

                // Schedule exact OS-level AlarmManager -> RestTimerReceiver heads-up notification (works in background & lockscreen)
                try {
                    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val intent = Intent(context, RestTimerReceiver::class.java).apply {
                        putExtra(RestTimerReceiver.EXTRA_CLIENT_NAME, clientName)
                        putExtra(RestTimerReceiver.EXTRA_EX_NAME, exName)
                        putExtra(RestTimerReceiver.EXTRA_PLAY_SOUND, playSound)
                    }
                    val pi = PendingIntent.getBroadcast(
                        context,
                        4201,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    val triggerAt = System.currentTimeMillis() + safeSec * 1000L
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        if (am.canScheduleExactAlarms()) {
                            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                        } else {
                            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                        }
                    } else {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                    }
                } catch (_: Exception) {}

                // AlarmManager handles exact wakeup & notification; release any legacy wake-lock
            }
        }

        @JavascriptInterface
        fun cancelBackgroundTimer() {
            runOnUiThread {
                cancelAlarmInternal()
            }
        }

        private fun cancelAlarmInternal() {
            try {
                val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(context, RestTimerReceiver::class.java)
                val pi = PendingIntent.getBroadcast(
                    context,
                    4201,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                am.cancel(pi)
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun playAlarmSound() {
            Thread {
                try {
                    val sampleRate = 44100
                    val durationSec = 1.15
                    val numSamples = (sampleRate * durationSec).toInt()
                    val pcm = ShortArray(numSamples)
                    // Warm Apple-style studio chime: C5 (523.25), E5 (659.25), G5 (783.99), B5 (987.77)
                    val notes = doubleArrayOf(523.25, 659.25, 783.99, 987.77)
                    val starts = doubleArrayOf(0.0, 0.11, 0.22, 0.34)
                    for (i in 0 until numSamples) {
                        val t = i.toDouble() / sampleRate
                        var sample = 0.0
                        for (nIdx in notes.indices) {
                            val dt = t - starts[nIdx]
                            if (dt >= 0.0) {
                                val f = notes[nIdx]
                                val env = Math.min(1.0, dt / 0.014) * Math.exp(-dt * 4.6)
                                val tone = Math.sin(2.0 * Math.PI * f * dt) * 0.72 +
                                           Math.sin(2.0 * Math.PI * f * 2.0 * dt) * 0.20 * Math.exp(-dt * 7.5) +
                                           Math.sin(2.0 * Math.PI * f * 3.0 * dt) * 0.08 * Math.exp(-dt * 11.0)
                                sample += tone * env * 0.34
                            }
                        }
                        val clamped = Math.max(-1.0, Math.min(1.0, sample))
                        pcm[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
                    }

                    val track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(pcm.size * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build()

                    track.write(pcm, 0, pcm.size)
                    track.play()
                    Thread.sleep(1250)
                    track.release()
                } catch (_: Exception) {}
            }.start()
        }

        @JavascriptInterface
        fun downloadBase64Xlsx(base64Data: String, fileName: String) {
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val mime = if (fileName.endsWith(".json", ignoreCase = true)) {
                        "application/json"
                    } else {
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    }
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("MediaStore insert failed")
                    resolver.openOutputStream(uri)?.use { it.write(bytes) }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } else {
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val outFile = File(downloadsDir, fileName)
                    FileOutputStream(outFile).use { it.write(bytes) }
                }
                Toast.makeText(context, "Сохранено в Загрузки: $fileName", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
