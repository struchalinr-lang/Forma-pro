package com.fittrainer.live

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

class RestTimerReceiver : BroadcastReceiver() {

    companion object {
        const val LEGACY_CHANNEL_ID = "forma_rest_timer_heads_up_v1"
        const val CHANNEL_ID = "forma_rest_timer_heads_up_v2"
        const val NOTIF_ID = 4201
        const val EXTRA_CLIENT_NAME = "extra_client_name"
        const val EXTRA_EX_NAME = "extra_ex_name"
        const val EXTRA_PLAY_SOUND = "extra_play_sound"
        const val EXTRA_TIMER_ID = "extra_timer_id"

        fun chimeUri(context: Context): Uri =
            Uri.parse("android.resource://${context.packageName}/${R.raw.forma_chime}")

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                try { nm.deleteNotificationChannel(LEGACY_CHANNEL_ID) } catch (_: Exception) {}
                if (nm.getNotificationChannel(CHANNEL_ID) != null) return
                val soundUri = chimeUri(context)
                val audioAttrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Таймер отдыха Forma Pro",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Всплывающие уведомления об окончании отдыха между подходами"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 220, 120, 220)
                    setSound(soundUri, audioAttrs)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(channel)
            }
        }

        fun cancelNotification(context: Context) {
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancelAll()
            } catch (_: Exception) {}
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        ensureChannel(context)
        val clientName = intent.getStringExtra(EXTRA_CLIENT_NAME)?.trim().orEmpty()
        val exName = intent.getStringExtra(EXTRA_EX_NAME)?.trim().orEmpty()
        val playSound = intent.getBooleanExtra(EXTRA_PLAY_SOUND, true)
        val timerId = intent.getStringExtra(EXTRA_TIMER_ID)?.trim().orEmpty()

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            if (timerId.isNotEmpty()) putExtra(EXTRA_TIMER_ID, timerId)
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            if (timerId.isNotEmpty()) timerId.hashCode() else 101,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (clientName.isNotEmpty()) {
            "Отдых окончен — $clientName"
        } else {
            "Отдых окончен"
        }
        val body = if (exName.isNotEmpty()) {
            "Пора к подходу • $exName"
        } else {
            "Пора переходить к следующему подходу"
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)

        if (playSound) {
            builder.setSound(chimeUri(context))
            builder.setVibrate(longArrayOf(0, 220, 120, 220))
        } else {
            builder.setSilent(true)
        }

        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(if (timerId.isNotEmpty()) timerId.hashCode() else NOTIF_ID, builder.build())
        } catch (_: Exception) {}
    }
}
